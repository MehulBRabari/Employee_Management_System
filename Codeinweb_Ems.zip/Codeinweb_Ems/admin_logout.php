<?php
session_start();

// require_once('config/connection.php');


unset($_SESSION['admin_id']); 

// session_unset();

header('location:index.php');

exit();

?>
