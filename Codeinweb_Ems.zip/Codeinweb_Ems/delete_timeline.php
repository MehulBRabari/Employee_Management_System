<?php require_once('config/connection.php'); ?>
<?php
$get_id = $_GET['delete_data'];

$delete_query = "DELETE FROM employee_timeline WHERE id = '$get_id'";

$run_delete_query = mysqli_query($conn,$delete_query);

if($run_delete_query)
{
    $success = 'success';
    header("refresh:2;URL='admin_dashboard.php");

}
else
{
    $fail = 'fail';
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Employee Profile | codeinweb Technologies</title>
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Datatable -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link rel="icon" type="image/icon/x" href="dist/img/codeinweblogo.png">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
 <?php require_once('includes/topnavbar.php'); ?>
  <!-- Main Sidebar Container -->
  <?php require_once('includes/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Profile</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">User Profile</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
      <?php if(isset($success))
{ ?>
<div class = "alert alert-success alert-dismissible" style="font-size:20px" >
<i class = "fa fa-spinner fa-spin"></i>TIMELINE DELETE SUCCESSFUL !! 
</div>
<?php } ?>

<?php if(isset($fail))  
{ ?>
<div class = "alert alert-danger alert-dismissible" style="font-size:20px" >
<i class = "icon fa fas-ban"></i> DATA NOT DELETED</div>
  <?php } ?>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3">
            <!-- Profile Image -->
            <!-- <div class="card card-primary card-outline"> -->
              <!-- <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle"
                       src="uploaded_images/<?php echo $fetch_data['emp_image'] ?>"
                      style="height:150px; width:250px;" alt="User profile picture">
                </div>
                <h3 class="profile-username text-center"><?php echo $fetch_data['first_name']; ?> <?php echo $fetch_data['last_name']; ?></h3>
                <p class="text-muted text-center"><?php echo $fetch_data['designation']?></p>
              </div> -->
              <!-- /.card-body -->
            <!-- </div> -->
            <!-- /.card -->

            <!-- About Me Box -->
           
            <!-- /.card -->
          </div>
          <!-- /.col -->
                    <div class="card-body">
                    <div class="card">
                      <div class="card-header">
                        <h3 class="card-title">Add New Timeline Event</h3>
                      </div>
                      <div class="card-body">
                        <form method="post" action="">
                          <div class="form-group">
                            <label for="join_date">Joining Date</label>
                            <input type="date" class="form-control" id="join_date" name="join_date" required>
                          </div>
                          <div class="form-group">
                            <label for="designation">Designation</label>
                            <input type="text" class="form-control" id="designation" name="designation" required>
                          </div>
                          <div class="form-group">
                            <label for="work_description">Work Description</label>
                            <input type="text" class="form-control" id="work_description" name="work_description" required>
                          </div>
                          <div class="form-group">
                            <label for="first_pro_date">First Project Assign Date</label>
                            <input type="date" class="form-control" id="first_pro_date" name="first_pro_date" required>
                          </div>

                          <div class="form-group">
                            <label for="first_pro_review">First Project Assign Review</label>
                            <textarea type="text" class="form-control" id="first_pro_review" name="first_pro_review" required></textarea>
                          </div>

                          <div class="form-group">
                            <label for="lead_new_pro">Lead New Project Review</label>
                            <textarea type="text" class="form-control" id="lead_new_pro" name="lead_new_pro" required></textarea>
                          </div>

                          <div class="form-group">
                            <label for="perform_review">Performance Review</label>
                            <textarea type="text" class="form-control" id="perform_review" name="perform_review" required></textarea>
                          </div>
                          
                          <div class="form-group">
                            <label for="promotion_date">Promotion Date</label>
                            <input type="date" class="form-control" id="promotion_date" name="promotion_date" required>
                          </div>

                          <div class="form-group">
                            <label for="promotion_dep">Promotion Department</label>
                            <input type="text" class="form-control" id="promotion_dep" name="promotion_dep" required>
                          </div>

                          <button type="submit" class="btn btn-primary">Add Timeline</button>

                        </form>
                      </div>
                    </div>
                 </div>
                    <!-- The timeline Table  -->
      <section class="content">              
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Time Line Table</h3>
            <!-- <a class="btn btn-sm btn-primary float-right" href="add_emp.php"><i class="fas fa-plus"></i>Add  Employee</a> -->
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Join Date</th>
                    <th>First Proj Review</th>
                    <th>Performance</th>
                    <th>Promotion Date</th>
                    <th>Action </th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $select_query = "SELECT * FROM employee_timeline";
                    $result = mysqli_query($conn,$select_query);
                    while($value = mysqli_fetch_array($result))
                    {
                    ?>
                  <tr>
                    <td><?php echo $value['join_date']; ?></td>
                    <td><?php echo $value['first_pro_date']; ?></td>
                    <td><?php echo $value['perform_review']; ?></td>
                    <td><?php echo $value['promotion_date']; ?></td>
                    <td class="project-actions text-right">
                          <!-- <a class="btn btn-secondary  btn-sm" href="emp_pay_salary.php?pay_amount=<?php echo $value['id']; ?>" title="Employee Pay Amount"><i class="fa-solid fa-sack-dollar" style="font-size:20px; color:white"></i></a> -->
                          <!-- <a class="btn btn-primary btn-sm" href="emp_view_data.php?view_data=<?php echo $value['id']; ?>" title="View Employee Profile"><i class="fas fa-folder"></i></a> -->
                          <a class="btn btn-info btn-sm" href="edit_emp_timeline.php?edit_data=<?php echo $value['id']; ?>" title="Edit Data"><i class="fas fa-pencil-alt"></i></a>
                          <a class="btn btn-danger btn-sm" href="delete_timeline.php?delete_data=<?php echo $value['id']; ?>" onclick="return confirm('Are you sure delete item');" title="Delete Data"><i class="fas fa-trash"></i></a>
                    </td>
                  </tr>
                  <?php } ?>
                  </tbody>
                  <tfoot>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      
  </section>




                  </div>
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              <!-- </div> -->
              <!-- /.card-body -->
            </div><!-- /.card -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      <!-- /.container-fluid -->
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php require_once('includes/footer.php'); ?>
  <!-- Control Sidebar -->
  <?php require_once('includes/javascript.php'); ?>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<!-- jQuery -->
<!-- <script src="plugins/jquery/jquery.min.js"></script> -->
<!-- Bootstrap 4 -->
<!-- <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script> -->
<!-- AdminLTE App -->
<!-- <script src="dist/js/adminlte.min.js"></script> -->
<!-- AdminLTE for demo purposes -->
<!-- <script src="dist/js/demo.js"></script> -->
</body>
</html>
