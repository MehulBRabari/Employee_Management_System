<?php


// $conn = mysqli_connect('localhost','root','','codeinweb_ems');

// if($conn)
// {
//     //echo "connection established successfully.";
// }
// else
// {
//     echo "connection failed:";
// }

// mysqli_select_db($conn, 'codeinweb_ems');

?>

<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "codeinweb_ems";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>