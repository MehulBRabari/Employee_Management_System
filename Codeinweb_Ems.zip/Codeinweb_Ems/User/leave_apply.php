<?php require_once('../config/connection.php'); ?>
<?php

if ($_SESSION['id'] == '')
{
	header('location:index.php');
}


$get_id = $_GET['employee_id'];

$select_query = "SELECT * FROM add_employee WHERE id = '$get_id'";

$select_data = mysqli_query($conn,$select_query);

$value = mysqli_fetch_array($select_data);


if(isset($_POST['submit']))
{
  $employeeID = $_POST['employeeID'];
  $emp_name = $_POST['emp_name'];
  $leave_type = $_POST['leave_type'];
  $select_leave = $_POST['select_leave'];
  $single_date = $_POST['single_date'];
  $leave_duration = $_POST['leave_duration'];
  $from_date = $_POST['from_date'];
  $to_date = $_POST['to_date'];
  $leave_description = $_POST['leave_description'];

  
  $insert_query = "INSERT INTO emp_leave(employeeID,emp_name,leave_type,select_leave,single_date,leave_duration,from_date,to_date,leave_description) VALUES('$employeeID','$emp_name','$leave_type','$select_leave','$single_date','$leave_duration','$from_date','$to_date','$leave_description')";

    
$insert_data = mysqli_query($conn,$insert_query);

if ($insert_data)
{
  $success = "success";
        header('refresh:2;URL=emp_leave_history.php');
}

else 
{
  $fail = "fail";

}


}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Employee Leave Form | Codeinweb Technologies</title>

  <!-- <style>
        .multiple-days-section {
            display: none;
        }
    </style> -->
    <script>   
        function toggleLeaveTypetwo() {
            const singleDay = document.getElementById('single-day');
            const multipleDays = document.getElementById('multiple-days');
            const singleDaySection = document.getElementById('single-day-section');
            const multipleDaysSection = document.getElementById('multiple-days-section');
 
            if (singleDay.checked) {
                singleDaySection.style.display = 'block';
            } 
            else{
              singleDaySection.style.display = 'none';
            }
            if (multipleDays.checked) {
                multipleDaysSection.style.display = 'block';
            } 
            else {
              multipleDaysSection.style.display = 'none';
            }
           
        }
    </script>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">

  <link rel="icon" type="image/icon/x" href="../dist/img/codeinweblogo.png">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
<?php require_once('../includes2/topnavbar.php'); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php require_once('../includes2/sidebar.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Leave Form </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <!-- <li class="breadcrumb-item"><a href="#">Home</a></li> -->
              <li class="breadcrumb-item active">Leave Application Form</li>
            </ol>
          </div>
          </div><!-- /.container-fluid -->
    </section>

           

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary card-outline">
            <?php if (isset($success)) { ?>
  <div class="alert alert-success alert-dismissible" style="font-size:20px">
    <i class="fa fa-spinner fa-spin" ></i> Leave Application Send !!!
  </div>
<?php } ?>

<!-- /.Fail Alert Box -->
<?php if (isset($fail)) { ?>
  <div class="alert alert-danger alert-dismissible" style="font-size: 17px">
    <i class="icon fas fa-ban"></i>  Application not send  !!!
  </div>
<?php } ?>  
              <div class="card-header">
                <h3 class="card-title">Fill Form</h3>
              </div>
              <!-- /.card-header -->      
        <form method="POST" >   
        <div class="card-body">

    <div classs="form-group" style="display: none;">
    <label for="employee-name">Employee id:</label>
    <input type="text" id="employee-name" value="<?php echo $value['employeeID']; ?>" class="form-control" name="employeeID" required>
    </div>
    
  <div classs="form-group">
    <label for="employee-name">Employee Name:</label>
    <input type="text" id="employee-name" class="form-control" name="emp_name" required>
    </div>

    <div class="form-group">
    <label for="leave-type">Leave Type:</label>
    <select id="leave-type" class="form-control" name="leave_type" required>
      <option>SELECT LEAVE</option>
        <option value="Sick Leave">Sick Leave</option>
        <option value="Casual Leave">Casual Leave</option>
        <option value="Annual Leave">Annual Leave</option>
        <!-- Add other leave types as needed -->
    </select>
    </div>
     
    <div class="form-group">
    <label>Select Leave:</label><br>
    <input type="radio" id="single-day" name="select_leave" value="single day" onclick="toggleLeaveTypetwo()">
    <label for="single-day" class="form-check-label">Single Day Leave</label><br>

    <input type="radio" id="multiple-days" name="select_leave" value="multiple day" onclick="toggleLeaveTypetwo()">
    <label for="multiple-days" class="form-check-label">Multiple Days Leave</label>
     <div>


     <div id="single-day-section" class="form-group mt-3">
        
     <label for="single-date">Date:</label>
        <input type="date" class="form-control" min="<?php echo date('Y-m-d'); ?>" name="single_date">
      
</div>
         <div class="form-group mt-3">
        <label for="leave-duration">Leave Duration:</label><br>
        <input type="radio"  name="leave_duration" value="Half Day">
        <label for="half-day" class="form-check-label">Half Day</label><br>
        <input type="radio"  name="leave_duration" value="Full Day">
        <label for="full-day" class="form-check-label">Full Day</label>
      
      </div>
    

    <div id="multiple-days-section" class="form-group mt-3">
        <label for="from-date">From Date:</label>
        <input type="date" id="from_date" min="<?php echo date('Y-m-d'); ?>" class="form-control" name="from_date">

        <label for="to-date">To Date:</label>
        <input type="date" id="to_date" min="<?php echo date('Y-m-d'); ?>" class="form-control" name="to_date">
      </div>

        <div class="form-group">
        <label for="leave-description">Leave Description:</label>
        <textarea id="leave-description" class="form-control" name="leave_description" rows="3" cols="50"></textarea>
        </div>

       <div class="card-footer">
                  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
       </div>
      
  </div>
</form>
</div>

            <!-- /.card -->

            <!-- general form elements -->
           
            <!-- /.card -->

            <!-- Input addon -->

            <!-- /.card -->
            <!-- Horizontal Form -->
            
            <!-- /.card -->

          </div>
          <!--/.col (left) -->
          <!-- right column -->
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 <?php require_once('../includes2/footer.php'); ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<?php require_once('../includes2/javascript.php'); ?>
<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<!-- <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script> -->
<!-- bs-custom-file-input -->
<!-- <script src="plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script> -->
<!-- AdminLTE App -->
<!-- <script src="dist/js/adminlte.min.js"></script> -->
<!-- AdminLTE for demo purposes -->
<!-- <script src="dist/js/demo.js"></script> -->
<!-- Page specific script -->
<!-- <script>
$(function () {
  bsCustomFileInput.init();
});
</script> -->
</body>
</html>
