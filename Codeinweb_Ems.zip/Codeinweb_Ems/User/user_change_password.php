<?php

require_once('../config/connection.php');

if(!empty($_POST['save']))
{
	$op = md5($_POST['oldpass']);
	$np = md5($_POST['newpass']);
	$cp = md5($_POST['cpass']);
	if($np == $cp)
	{
         $query = "SELECT * FROM add_employee WHERE password = '$op'";
         $result = mysqli_query($conn,$query);
         $count = mysqli_fetch_array($result);
         if($count > 0)
         {
           $update_query = "UPDATE add_employee SET password = '$np' where id='".$_SESSION['id']."'";
           mysqli_query($conn,$update_query);

           $success = "success";
           header('refresh:2;URL=index.php');

        }
         else
         {
          $fail = "fail";
        }
	}
	else
	{
	  $notmatch = "notmatch";
	}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>User Change Password</title>

  <link rel="icon" type="image/x-icon" href="../dist/img/icon.png">
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">

  <link rel="icon" type="image/icon" href="../dist/img/codeinweblogo.png">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
 <?php require "../includes2/topnavbar.php"; ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
 
  <?php require "../includes2/sidebar.php"; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1></h1>
          </div>
          <div class="col-sm-6">
            <!-- <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"></a></li>
              <li class="breadcrumb-item active"></li>
            </ol> -->
          </div>
        </div>
      </div>
   </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">

          <?php if (isset($success)) { ?>
          <div class="alert alert-success alert-dismissible" style="font-size:20px">
          <i class="fa fa-spinner fa-spin" ></i> Your Password Change !!!
          </div>
          <?php } ?>

          <?php if (isset($fail)) { ?>
         <div class="alert alert-danger alert-dismissible" style="font-size: 17px">
          <i class="icon fas fa-ban"></i> Old Password Incorrect  !!!
          </div>
          <?php } ?>
          
          <?php if (isset($notmatch)) { ?>
         <div class="alert alert-danger alert-dismissible" style="font-size: 17px">
          <i class="icon fas fa-ban"></i>New And Confirm Password Not Match !!!
          </div>
          <?php } ?>

        <div class="row">
          <!-- left column -->
          <div class="col-md-6 m-auto">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Change Password</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="post" id="quickForm">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Old Password</label>
                    <input type="password" name="oldpass" class="form-control" id="exampleInputEmail1" placeholder="Enter Old Password">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">New Password</label>
                    <input type="password" name="newpass" class="form-control" id="exampleInputPassword1" placeholder="Enter New Password">
                  </div>
                   
                  <div class="form-group">
                    <label for="exampleInputPassword1">Confirm Password</label>
                    <input type="password" name="cpass" class="form-control" id="exampleInputPassword1" placeholder="Enter Confirm Password">
                  </div>
                <!-- /.card-body -->
                <!-- <div class="card-footer"> -->
                  <input type="submit" name="save"  class="btn btn-primary">
                  <a class="btn btn-secondary" onclick="window.history.go(-1); return false;"><i class="fa fa-backward"></i> Go Back</a>

                <!-- </div> -->
               </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php require "../includes2/footer.php"; ?>

  <!-- Control Sidebar -->
  <!-- <aside class="control-sidebar control-sidebar-dark"> -->
    <!-- Control sidebar content goes here -->
  <!-- </aside> -->
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<?php require "../includes2/javascript.php"; ?>
</body>
</html>
