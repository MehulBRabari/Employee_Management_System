<?php require_once('../config/connection.php'); ?>
<?php 
if ($_SESSION['id'] == '')
{
	header('location:index.php');
}

$get_id = $_GET['salary_sleep'];

$query = "SELECT * FROM employee_salary WHERE id = '$get_id'";

$result = mysqli_query($conn, $query);

$salary_data = mysqli_fetch_array($result);

$total_earnings = $salary_data['basic_pay'] + $salary_data['incentive_pay'] + $salary_data['house_rent_allowance'] + $salary_data['meal_allowance'];
$total_deductions = $salary_data['provident_fund'] + $salary_data['professional_tax'] + $salary_data['loan'];
$net_pay = $total_earnings - $total_deductions;

?>
<?php

$employee_id = $_GET['employee_id'];

$query = "SELECT * FROM add_employee WHERE id = '$employee_id'";

$result = mysqli_query($conn,$query);

$value = mysqli_fetch_array($result);

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>All Employee Salary Data | Codeinweb Technologies</title>

  <style>
    .payslip {
        max-width: 800px;
        margin: auto;
        border: 1px solid #000;
        padding: 20px;
        font-family: Arial, sans-serif;
    }
    .payslip-header, .payslip-footer {
        text-align: center;
        margin-bottom: 20px;
    }
    .payslip-body {
        margin-bottom: 20px;
    }
    .table th, .table td {
        border: 1px solid #000 !important;
    }
    .signature {
        margin-top: 50px;
    }
  </style>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
  <link rel="stylesheet" type="text/css" href="dist/css/all.min.css">
  <!-- Favicon icon -->
  <link rel="icon" type="image/x-icon" href="../dist/img/codeinweblogo.png" />
  
  <!-- Include jsPDF and html2canvas libraries -->
  <script src="../dist/js/jspdf.umd.min.js"></script>
  <script src="../dist/js/html2canvas.min.js"></script>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
 <?php require_once('../includes2/topnavbar.php'); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
 <?php require_once('../includes2/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Employee Salary Slip</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item active">Salary Slip</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
    <div class="card rounded-0 card-outline card-primary shadow">
        <div class="card-header rounded-0">
            <h5 class="card-title">Generated Salary Slip</h5>
            <div class="card-tools">
               <a class="btn btn-success mr-2" onclick="window.print()"><i class="fa fa-print"></i> Print</a>
               <button class="btn btn-primary mr-2" id="downloadPDF"><i class="fa fa-download"></i> Download PDF</button>
               <a class="btn btn-secondary float-right" onclick="window.history.go(-1); return false;"><i class="fa fa-backward"></i> Go Back</a>
            </div>
        </div>
        <div class="card-body rounded-0">
            <div class="payslip" id="payslipContent">
        <div class="payslip-header">
            <h2>Codeinweb Technologies</h2>
            <p>1015, Ashram Rd, near Vallabh Sadan Riverfront, opp. City Gold Cinema, Vishalpur, Muslim Society, Navrangpura, Ahmedabad, </p>
        </div>
        
        <div class="payslip-body">
            <div class="row">
                 <div class="col-md-6">
                    <p>Date of Pay : <strong><?php echo $salary_data['date'];?></strong></p>
                    <p>Pay Period: <strong><?php echo $salary_data['pay_period'];?></strong></p>
                    <p>Worked Days: <strong><?php echo $salary_data['worked_days'];?></strong></p>
                </div>
                <div class="col-md-6">
                    <p>Employee Name: <strong><?php echo $value['first_name'];?> <?php echo $value['last_name'];?></strong></p>
                    <p>Designation: <strong><?php echo $value['designation'];?></strong></p>
                    <p>Address: <strong><?php echo $value['address'];?></strong></p>
                </div>
            </div>
            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Earnings</th>
                        <th>Amount</th>
                        <th>Deductions</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Basic Pay</td>
                        <td><?php echo $salary_data['basic_pay']; ?></td>
                        <td>Provident Fund</td>
                        <td><?php echo $salary_data['provident_fund']; ?></td>
                    </tr>
                    <tr>
                        <td>Incentive Pay</td>
                        <td><?php echo $salary_data['incentive_pay']; ?></td>
                        <td>Professional Tax</td>
                        <td><?php echo $salary_data['professional_tax']; ?></td>
                    </tr>
                    <tr>
                        <td>House Rent Allowance</td>
                        <td><?php echo $salary_data['house_rent_allowance']; ?></td>
                        <td>Loan</td>
                        <td><?php echo $salary_data['loan']; ?></td>
                    </tr>
                    <tr>
                        <td>Meal Allowance</td>
                        <td><?php echo $salary_data['meal_allowance']; ?></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Total Earnings</th>
                        <th><?php echo $total_earnings; ?></th>
                        <th>Total Deductions</th>
                        <th><?php echo $total_deductions; ?></th>
                    </tr>
                    <tr>
                        <th colspan="3">Net Pay</th>
                        <th><?php echo $net_pay; ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>

        <div class="signature row">
            <div class="col-md-6 text-center">
                <p>Employer Signature</p>
            </div>
            <div class="col-md-6 text-center">
                <p>Employee Signature</p>
            </div>
        </div>

        <div class="text-center mt-4">
            <p>This is a system generated payslip</p>
        </div>
    </div>  

        </div>
    </div> 
  </div>
        </div>
      </div>
    </section>
  </div>

<?php require_once('../includes2/javascript.php'); ?>

 <?php require_once('../includes2/footer.php'); ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('downloadPDF').addEventListener('click', function () {
        const { jsPDF } = window.jspdf;
        html2canvas(document.getElementById('payslipContent')).then(canvas => {
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF('p', 'pt', 'a4');
            const imgProps = pdf.getImageProperties(imgData);
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

            pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
            pdf.save('Salary_Slip.pdf');
        });
    });
});
</script>

</body>
</html>
