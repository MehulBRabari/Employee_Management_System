<?php require_once('../config/connection.php'); ?>
<?php
if ($_SESSION['id'] == '')
{
    header('location:index.php');
}

$select_query = "SELECT ae.id AS employee_id, ae.employeeID, ae.first_name, ae.last_name, es.date, es.remark, es.id AS salary_id
                 FROM add_employee ae
                 JOIN employee_salary es ON es.employeeID = ae.employeeID"; // Adjust the join condition as per your schema

$result = mysqli_query($conn, $select_query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Salary Slip | Codeinweb Technologies</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
  <!-- Favicon icon -->
  <link rel="icon" type="image/x-icon" href="../dist/img/codeinweblogo.png" />
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
 <?php require_once('../includes2/topnavbar.php'); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
 <?php require_once('../includes2/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Collect Your Salary Slip</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item active">Salary Tables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->
            <div class="card card-primary card-outline">
              <div class="card-header">
                <h3 class="card-title">Employee Salary Table</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Employee Id</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Date Of Salary</th>
                    <th>Remark</th>
                    <th class="text-center">Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                    while($value = mysqli_fetch_array($result))
                    {
                    ?>
                  <tr>
                    <td><?php echo $value['employeeID']; ?></td>
                    <td><?php echo $value['first_name']; ?></td>
                    <td><?php echo $value['last_name']; ?></td>
                    <td><?php echo $value['date']; ?></td>
                    <td><?php echo $value['remark']; ?></td>
                    <td class="project-actions text-center">
                          <a class="btn btn-info btn-sm" href="salary_sleep.php?salary_sleep=<?php echo $value['salary_id']; ?>&employee_id=<?php echo $value['employee_id']; ?>" title="Salary Slip"><i class="nav-icon fas fa-book"></i></a>
                          <a class="btn btn-danger btn-sm" href="delete_salary.php?delete_data=<?php echo $value['salary_id']; ?>" onclick="return confirm('Are you sure you want to delete this item?');" title="Delete Data"><i class="fas fa-trash"></i></a>
                    </td>
                  </tr>
                  <?php } ?>
                  </tbody>
                  <tfoot>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php require_once('../includes2/footer.php'); ?>
  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<?php require_once('../includes2/javascript.php'); ?>
</body>
</html>
