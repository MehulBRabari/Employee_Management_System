<?php require_once('../config/connection.php'); ?>

<?php
if ($_SESSION['id'] == '')
{
	header('location:index.php');
}
// Fetch all employee records
$select_query = "SELECT * FROM add_employee";
$run_select_query = mysqli_query($conn, $select_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>All Employee Profile | Contacts</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
  <link rel="icon" type="image/x-icon" href="../dist/img/codeinweblogo.png">
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
  <!-- Navbar -->
  <?php require_once('../includes2/topnavbar.php'); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php require_once('../includes2/sidebar.php'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>All Employee</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <!-- <li class="breadcrumb-item"><a href="#">Home</a></li> -->
              <li class="breadcrumb-item active">All Employee Profile</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <!-- <div class="card card-solid"> -->
        <!-- <div class="card-body pb-0"> -->
          <div class="row">
            <div class="col-12">
              <table class="table table-striped">
                <!-- <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Job Title</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Action</th>
                  </tr>
                </thead> -->
                <tbody>
          <div class="row">
          <?php while($row = mysqli_fetch_assoc($run_select_query)) { ?>
         <div class="col-12 col-sm-6 col-md-4 d-flex align-items-stretch flex-column">
           <div class="card card-primary card-outline bg-light d-flex flex-fill">
             <div class="card-header text-muted border-bottom-0">
               <?php  echo $row['designation']; ?>
             </div>
             <div class="card-body pt-0">
               <div class="row">
                 <div class="col-7">
                   <h2 class="lead"><b><?php echo $row['first_name'] . " " . $row['last_name']; ?></b></h2>
                   <p class="text-muted text-sm"><b>Email: </b> <?php  echo $row['email']; ?> </p>
                   <ul class="ml-4 mb-0 fa-ul text-muted">
                     <li class="small"><span class="fa-li"><i class="fas fa-lg fa-building"></i></span> Address:<?php  echo $row['address']; ?> </li>
                     <li class="small"><span class="fa-li"><i class="fas fa-lg fa-phone"></i></span> Phone #:<?php echo substr($row['mobile'],0 ,5).str_repeat("*", strlen($row['mobile'])-5);; ?></li>
                   </ul>
                 </div>
                 <div class="col-5 text-center">
                   <img src="../uploaded_images/<?php echo $row['emp_image'] ?>" alt="user-avatar" class="img-circle img-fluid">
                 </div>
               </div>
             </div>
             <div class="card-footer">
               <div class="text-right">
                 <a href="#" class="btn btn-sm bg-teal">
                   <i class="fas fa-comments"></i>
                 </a>
                 <a  href="leave_apply.php?employee_id=<?php echo $row['id']; ?>" title="Applay Leave" class="btn btn-sm btn-success">
                   <i class="fas fa-tree"></i> Applay Leave
                 </a>
                 <a  href="emp_timeline.php?view_data=<?php echo $row['id']; ?>" title="View Employee Profile" class="btn btn-sm btn-primary">
                   <i class="fas fa-user"></i> View Profile
                 </a>
               </div>
             </div>
           </div>
         </div>
         <?php } ?>
              </div>
                </tbody>
              </table>
            </div>
         
        <!-- /.card-body -->
        <!-- /.card-footer -->
      <!-- /.card -->
    </section>
    <!-- /.content -->
  <!-- /.content-wrapper -->
  </div>

  <?php require_once('../includes2/footer.php'); ?>
  
 <div>
  <!-- Control Sidebar -->
  <?php require_once('../includes2/javascript.php'); ?>

  <!-- /.control-sidebar -->
<!-- ./wrapper -->

<!-- jQuery -->
</body>
</html>
