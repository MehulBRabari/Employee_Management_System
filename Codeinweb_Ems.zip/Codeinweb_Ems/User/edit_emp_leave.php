<?php require_once('../config/connection.php'); ?>
<?php

if ($_SESSION['id'] == '')
{
	header('location:index.php');
}

$get_id = $_GET['edit_leave'];

$query = "SELECT * FROM emp_leave WHERE id = '$get_id'";

$run_query = mysqli_query($conn,$query);

$row = mysqli_fetch_array($run_query);

if(isset($_POST['update']))
{
  $emp_name = $_POST['emp_name'];
  $leave_type = $_POST['leave_type'];
  $select_leave = $_POST['select_leave'];
  $single_date = $_POST['single_date'];
  $leave_duration = $_POST['leave_duration'];
  $from_date = $_POST['from_date'];
  $to_date = $_POST['to_date'];
  $leave_description = $_POST['leave_description'];

  
  $update_query = "UPDATE emp_leave SET emp_name='$emp_name',leave_type='$leave_type',select_leave='$select_leave',single_date='$single_date',leave_duration='$leave_duration',from_date='$from_date',to_date='$to_date',leave_description='$leave_description' WHERE id='$get_id'";

  $run_update_query = mysqli_query($conn,$update_query);

if ($run_update_query)
{
  $success = "success";
  header('refresh:2;URL=emp_leave_history.php');
}

else 
{
  $fail = "fail";

}


}



?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Employee Leave Form | codeinweb Technologies</title>

  <!-- <style>
        .multiple-days-section {
            display: none;
        }
    </style> -->
    <script>   
        function toggleLeaveTypetwo() {
            const singleDay = document.getElementById('single-day');
            const multipleDays = document.getElementById('multiple-days');
            const singleDaySection = document.getElementById('single-day-section');
            const multipleDaysSection = document.getElementById('multiple-days-section');
 
            if (singleDay.checked) {
                singleDaySection.style.display = 'block';
            } 
            else{
              singleDaySection.style.display = 'none';
            }
            if (multipleDays.checked) {
                multipleDaysSection.style.display = 'block';
            } 
            else {
              multipleDaysSection.style.display = 'none';
            }
           
        }
    </script>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">

  <link rel="icon" type="image/icon/x" href="../dist/img/codeinweblogo.png">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
<?php require_once('../includes2/topnavbar.php'); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php require_once('../includes2/sidebar.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Leave Form </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <!-- <li class="breadcrumb-item"><a href="#">Home</a></li> -->
              <li class="breadcrumb-item active">Edit Leave</li>
            </ol>
          </div>
      </div><!-- /.container-fluid -->
    </section>

           

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
            <?php if (isset($success)) { ?>
  <div class="alert alert-success alert-dismissible" style="font-size:20px">
    <i class="fa fa-spinner fa-spin" ></i> Data Updated !!!
  </div>
<?php } ?>

<!-- /.Fail Alert Box -->
<?php if (isset($fail)) { ?>
  <div class="alert alert-danger alert-dismissible" style="font-size: 17px">
    <i class="icon fas fa-ban"></i>  Data Not Updated  !!!
  </div>
<?php } ?>  
              <div class="card-header">
                <h3 class="card-title">Fill Form</h3>
            <a class="btn btn-light text-blue float-right" onclick="window.history.go(-1); return false;"><i class="fa fa-backward"></i> Go Back</a>
              
              </div>
              <!-- /.card-header -->
        
              
        <form method="POST" >   
        <div class="card-body">
    <div classs="form-group">
    <label for="employee-name">Employee Name:</label>
    <input type="text" id="employee-name" value="<?php echo $row['emp_name']; ?>" class="form-control" name="emp_name" required>
    <div>

    <div class="form-group">
    <label for="leave-type">Leave Type:</label>
    <select id="leave-type" class="form-control" name="leave_type" required>
        <option value="sick" <?php  if($row['leave_type'] == 'sick') { echo "selected"; } ?>>Sick Leave</option>
        <option value="casual" <?php  if($row['leave_type'] == 'casual') { echo "selected"; } ?>>Casual Leave</option>
        <option value="annual" <?php  if($row['leave_type'] == 'annual') { echo "selected"; } ?>>Annual Leave</option>
        <!-- Add other leave types as needed -->
    </select>
    </div>
     
    <div class="form-group">
    <label>Select Leave:</label><br>
    <input type="radio" id="single-day" name="select_leave" value="single day" <?php if($row['select_leave'] == 'single day') { echo "checked"; } ?> onclick="toggleLeaveTypetwo()">
    <label for="single-day" class="form-check-label">Single Day Leave</label><br>

    <input type="radio" id="multiple-days" name="select_leave" value="multiple day" <?php if($row['select_leave'] == 'multiple day') { echo "checked"; } ?> onclick="toggleLeaveTypetwo()">
    <label for="multiple-days" class="form-check-label">Multiple Days Leave</label>
     <div>


     <div id="single-day-section" class="form-group mt-3">
        
     <label for="single-date">Date:</label>
        <input type="date" value="<?php echo $row['single_date']; ?>" class="form-control" name="single_date">
      

        <label for="leave-duration" class="mt-3">Leave Duration:</label><br>
        <input type="radio"  name="leave_duration" value="half" <?php if($row['leave_duration'] == 'half' ) {echo "checked"; }?>>
        <label for="half-day" class="form-check-label">Half Day</label><br>
        <input type="radio"  name="leave_duration" value="full" <?php if($row['leave_duration'] == 'full' ) { echo "checked"; } ?>>
        <label for="full-day" class="form-check-label">Full Day</label> 
      </div>
    

    <div id="multiple-days-section" class="form-group mt-3">
        <label for="from-date">From Date:</label>
        <input type="date" id="from_date" value="<?php echo $row['from_date']; ?>" class="form-control" name="from_date">

        <label for="to-date">To Date:</label>
        <input type="date" id="to_date" value="<?php echo $row['to_date']; ?>" class="form-control" name="to_date">
      </div>

        <div class="form-group">
        <label for="leave-description">Leave Description:</label>
        <input type="text" id="leave-description" value="<?php echo $row['leave_description']; ?>" class="form-control" name="leave_description">
        </div>

       <div class="card-footer">
                  <button type="submit" name="update" class="btn btn-primary">Update Leave</button>
       </div>
      
  </div>
</form>
</div>

            <!-- /.card -->

            <!-- general form elements -->
           
            <!-- /.card -->

            <!-- Input addon -->

            <!-- /.card -->
            <!-- Horizontal Form -->
            
            <!-- /.card -->

          </div>
          <!--/.col (left) -->
          <!-- right column -->
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 <?php require_once('../includes2/footer.php'); ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<?php require_once('../includes2/javascript.php'); ?>
<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<!-- <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script> -->
<!-- bs-custom-file-input -->
<!-- <script src="plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script> -->
<!-- AdminLTE App -->
<!-- <script src="dist/js/adminlte.min.js"></script> -->
<!-- AdminLTE for demo purposes -->
<!-- <script src="dist/js/demo.js"></script> -->
<!-- Page specific script -->
<!-- <script>
$(function () {
  bsCustomFileInput.init();
});
</script> -->
</body>
</html>
