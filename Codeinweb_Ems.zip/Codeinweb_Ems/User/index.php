<?php require_once('../config/connection.php'); ?>
<?php 

// session_start();

if (isset($_SESSION['id']) != '') {
    header("location:user_dashboard.php");
    exit();
}

if (isset($_POST['submit'])) {
    $emp_sql = "select * from add_employee where email='". mysqli_real_escape_string($conn, $_POST['email']) . "'AND BINARY password='" . mysqli_real_escape_string($conn, md5($_POST['password'])) . "'";
    $emp_query = mysqli_query($conn, $emp_sql);
    $emp_fetch = mysqli_fetch_array($emp_query);
    $emp_rows = mysqli_num_rows($emp_query);

    if ($emp_rows > 0) {
        if ($emp_fetch['status'] == '0') {
          $block = "block";
        } else {
            $_SESSION['id'] = $emp_fetch['id'];
           
            $success = "success";
            header('refresh:2;URL=user_dashboard.php');
            // exit();
        }
    } else {
        $fail = "fail";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>User Login | Codeinweb Technologies</title>
  
  <style>
    body {
      background-image: url('../dist/img/user2.avif');
      background-repeat: no-repeat;
      background-size: cover;
      background-position: center center;
    }
  </style>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="../plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <link rel="icon" type="image/x-icon" href="../dist/img/codeinweblogo.png">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">

  <!--- Javascript ---->
  <script>
    function myFunction() {
      var x = document.getElementById("myInput");
      if (x.type === "password") {
        x.type = "text";
      } else {
        x.type = "password";
      }
    }
  </script>

</head>
<body class="hold-transition login-page">

<div class="login-box">
  <div class="login-logo">
    <img src="../dist/img/codeinweb.png" height="70" width="230">
  </div>

    <?php if (isset($success)) { ?>
    <div class="alert alert-success alert-dismissible" style="font-size:20px">
      <i class="fa fa-spinner fa-spin"></i> Good to see you again !!!
    </div>
    <?php } ?>

    <?php if (isset($fail)) { ?>
    <div class="alert alert-danger alert-dismissible" style="font-size: 17px">
      <i class="icon fas fa-ban"></i> Invalid email or password !!!
    </div>
    <?php } ?>

    <?php if (isset($block)) { ?>
    <div class="alert alert-danger alert-dismissible" style="font-size: 17px">
      <i class="icon fas fa-ban"></i> Your Account is Block Please contact Admin !!!
    </div>
    <?php } ?>

  <div class="card card-primary card-outline">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Sign in to start your session</p>

      <form action="" method="post">
        <div class="input-group mb-3">
          <input type="email" name="email" class="form-control" placeholder="Email" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" name="password" id="myInput" class="form-control" placeholder="Password" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span onclick="myFunction()" class="fa fa-fw fa-eye field-icon toggle-password"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <div class="icheck-primary">
              <p class="mb-1">
                <a href="user_forgot_password.php">I forgot my password</a>
              </p>
            </div> 
          </div>
          <div class="col-4">
            <button type="submit" name="submit" class="btn btn-primary btn-block">Sign In</button>
            <a href="/codeinweb_ems" class="btn btn-secondary btn-block">Admin</a>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- jQuery -->
<script src="../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
</body>
</html>
