<?php

function getNextEmployeeID($conn) {
    $query = "SELECT MAX(employeeID) as max_id FROM add_employee";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $maxID = $row['max_id'];

    if ($maxID) {
        $num = (int)substr($maxID, 3); // Extract numeric part of the max ID
        $newID = 'CIW' . str_pad($num + 1, 5, '0', STR_PAD_LEFT); // Increment and format the new ID
    } else {
        $newID = 'CIW00001'; // Start from CIW00001 if no records found
    }

    return $newID;
}
?>
