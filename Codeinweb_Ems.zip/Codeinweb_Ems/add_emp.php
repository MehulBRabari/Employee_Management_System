<?php

require "config/connection.php";

if ($_SESSION['admin_id'] == '') {
    header('location:index.php');
}

if (isset($_POST['submit'])) {
    // $employeeID = $_POST['employeeID'];
    $First_Name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $mobile = $_POST['mobile'];
    $emobile = $_POST['emobile'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $designation = $_POST['designation'];
    $position = $_POST['position'];
    $experience = $_POST['experience'];
    $address = $_POST['address'];
    $joining_date = $_POST['joining_date'];
    $employee_proof_id = $_POST['employee_proof_id'];
    $reporting_person = $_POST['reporting_person'];

    // Employee document image uploaded
    $proof_id_image_name = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $proof_id_image_name = 'proof_id_doc' . time() . '_' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], 'uploaded_images/' . $proof_id_image_name);
    }

    // Employee Profile image uploaded
    $profile_image_name = '';
    if (isset($_FILES['emp_image']) && $_FILES['emp_image']['error'] == UPLOAD_ERR_OK) {
        $profile_image_name = 'profile_' . time() . '_' . basename($_FILES['emp_image']['name']);
        move_uploaded_file($_FILES['emp_image']['tmp_name'], 'uploaded_images/' . $profile_image_name);
    }

    // $employeeID = 'CIW/00001/' . date("dmY") . '/' . rand(1000, 5009);

    $insert_query = "INSERT INTO add_employee(first_name, last_name, gender, dob, mobile, emobile, 
    email, password, designation,position, experience , address, joining_date,employee_proof_id,image,reporting_person,emp_image)
    VALUES('$First_Name','$last_name','$gender','$dob','$mobile','$emobile','$email','$password',
    '$designation','$position','$experience','$address','$joining_date','$employee_proof_id','$proof_id_image_name','$reporting_person','$profile_image_name')";

    $insert_data = mysqli_query($conn, $insert_query);

    if ($insert_data) {
      $last_id = mysqli_insert_id($conn);
        if($last_id)
        {
          // $code = rand(1,99999);
          $user_id = "CIW0000".$last_id;
          $query = "UPDATE add_employee SET employeeID = '$user_id' WHERE id = '".$last_id."'";
          $res = mysqli_query($conn,$query);
        }
        $success = "success";
        header('refresh:2;URL=manage_all_emp.php');
    } else {
        $fail = "fail";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Add New Employee | Codeinweb Technologies</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href="plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Bootstrap4 Duallistbox -->
  <link rel="stylesheet" href="plugins/bootstrap4-duallistbox/bootstrap-duallistbox.min.css">
  <!-- BS Stepper -->
  <link rel="stylesheet" href="plugins/bs-stepper/css/bs-stepper.min.css">
  <!-- dropzonejs -->
  <link rel="stylesheet" href="plugins/dropzone/min/dropzone.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
   
  <link rel="icon" type="image/x-icon" href="dist/img/codeinweblogo.png">


</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
 <?php require_once('includes/topnavbar.php'); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
 <?php require_once('includes/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Employee Form</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <!-- <li class="breadcrumb-item"><a href="#">Home</a></li> -->
              <li class="breadcrumb-item active">Employee  Form</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <!-- /.card -->
<?php if(isset($success))
{ ?>
<div class = "alert alert-success alert-dismissible" style="font-size:20px" >
<!-- <i class = "fa fa-spinner fa-spin"></i>EMPLOYEE ADDED SUCCESSFUL !!  -->
<i class="fa fa-spinner fa-spin"></i>EMPLOYEE ADDED SUCCESSFUL !! 
</div>
<?php } ?>

<?php if(isset($fail))  
{ ?>
<div class = "alert alert-danger alert-dismissible" style="font-size:20px" >
<i class = "icon fa fas-ban"></i> DATA NOT ADDED</div>
<?php } ?>
  
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default card-primary card-outline">
          <div class="card-header">
            <h3 class="card-title">Add Employee</h3>

            <div class="card-tools">
              <!-- <button type="button" class="btn btn-tool" data-card-widget="collapse">
                <i class="fas fa-minus"></i>
              </button> -->
              <button type="button" class="btn btn-tool" data-card-widget="remove">
                <i class="fas fa-times"></i>
              </button>
            </div>
          </div>

         
          <!-- /.card-header -->
          <form action="" method="post" enctype="multipart/form-data"> 
          <div class="card-body">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>First Name:<span style="color: red;">*</span></label>
                 <input type="text" name="first_name" class="form-control" placeholder="First name"  required>
                </div>
               </div>
                <!-- /.form-group -->
                <div class="col-md-4">
                <div class="form-group">
                  <label>Last Name:<span style="color: red;">*</span></label>
                  <input type="text" name="last_name" class="form-control" placeholder="Last name" required>
                </div>
                </div>


                <div class="col-md-4">
                <div class="form-group">
                  <label>Gender:<span style="color: red;">*</span></label><br>
                 <input type="radio"name="gender" value="male"   required>
                 <label>Male:</label>
                 <input type="radio"name="gender" value="female"  required>
                 <label>female:</label>
                </div>
               </div>

                <div class="col-md-4">
                <div class="form-group">
                  <label>Date Of Birth:<span style="color: red;">*</span></label>
                  <input type="date" name="dob" class="form-control" max="<?php echo date('Y-m-d'); ?>" required>
                </div>
                </div>

                <!-- /.form-group -->
                <div class="col-md-4">
                <div class="form-group">
                  <label>Mobile Number:<span style="color: red;">*</span></label>
                 <input type="tel"name="mobile" class="form-control" placeholder="Phone Number" maxlength="12" required>
                </div>
               </div>

               <div class="col-md-4">
                 <div class="form-group">
                  <label>Emergency Mobile Number:</label>
                  <input type="tel" name="emobile" class="form-control" placeholder="Emergency Mobile Number" maxlength="12">
                </div>
                </div>

              <!-- /.col -->
              <div class="col-md-4">
              <div class="form-group">
                  <label>Email:<span style="color: red;">*</span></label>
                  <input type="email" name="email" class="form-control" placeholder="Email" required>
                </div>
                </div>

                <div class="col-md-4">
                <div class="form-group">
                  <label>Password:<span style="color: red;">*</span></label>
                 <input type="password" name="password" class="form-control" placeholder="Password" required>
                </div>
               </div>
                <!-- /.form-group -->
                <div class="col-md-4">
                <div class="form-group">
                  <label>Designation:</label>
                  <input type="" name="designation" class="form-control" placeholder="Designation">
                </div>
                </div>

                <div class="col-md-4">
                <div class="form-group">
                  <label>Position:<span style="color: red;">*</span></label>
                  <select class="form-control"  name="position" required>
                    <option>SELECT POSITION</option>
                    <option value="Senior">Senior</option>
                    <option value="Junior">Junior</option>
                    <option value="Team Leader">Team Leader</option>
                    <option value="Project Manager">Project Manager</option>
                  </select>
               </div>
               </div>


               <div class="col-md-4">
                <div class="form-group">
                  <label>Experience:<span style="color: red;">*</span></label>
                  <select class="form-control"  name="experience" required>
                    <option>SELECT EXPERIENCE</option>
                    <option value="Trained">Trained</option>
                    <option value="Fresher">Fresher</option>
                    <option value="Team Leader">1 Year Experience</option>
                    <option value="Team Leader">2 Year Experience</option>
                    <option value="Team Leader">3 Year Experience</option>
                    <option value="Team Leader">4 Year Experience</option>
                    <option value="Team Leader">5 Year Experience</option>
                    <option value="Team Leader">6 Year Experience</option>
                    <option value="Team Leader">7 Year Experience</option>
                    <option value="Team Leader">8 Year Experience</option>
                    <option value="Team Leader">9 Year Experience</option>
                    <option value="Team Leader">10 Year Experience</option>
                  </select>
               </div>
               </div>
                <!-- /.form-group -->
           
                <div class="col-md-4">
                <div class="form-group">
                  <label>Address:</label>
                  <input type="text" name="address" class="form-control" placeholder="Address">
                </div>
                </div>

                <div class="col-md-4">
                <div class="form-group">
                  <label>Joining Date:<span style="color: red;">*</span></label>
                  <input type="date" name="joining_date" class="form-control" required>
                </div>
                </div>
                
                <div class="col-md-4">
                <div class="form-group">
                  <label>Choose Your Id:<span style="color: red;">*</span></label>
                  <select class="form-control"  name="employee_proof_id" required>
                    <option>SELECT ID</option>
                    <option value="PAN Card">PAN Card</option>
                    <option value="Aadhar card">Aadhar card</option>
                    <option value="Voter ID Card">Voter ID Card</option>
                  </select>
               </div>
               </div>


              <div class="col-md-4">
                <div class="form-group">
                  <label>Upload Proof Id:<span style="color: red;">*</span></label>
                  <input type="file" name="image" class="form-control" required>
                  <!-- accept="application/pdf" use for uploded pdf  -->
                </div>
                </div>
                 
                <div class="col-md-4">
                <div class="form-group">
                  <label>Reporting Person:</label>
                  <select class="form-control"  name="reporting_person" required>
                    <option>SELECT PERSON</option>
                    <option value="Manager">Manager</option>
                    <option value="HR">HR</option>
                  </select>
               </div>
               </div>
               
               <div class="col-md-4">
                <div class="form-group">
                  <label>Employee Profile Image</label>
                  <input type="file" name="emp_image" class="form-control">
                </div>
                </div>

              <div class="col-md-12">
                <div class="form-group">
                  <button type="submit" value="submit" name="submit" class="btn btn-primary">Submit</button>
                </div>
              </div>
              <!-- /.col -->
    
          </div>
            <!-- /.row -->
          </div>
          <!-- /.card-body -->
          <div class="card-footer">
           
          </div>
        </div>
</form>
        <!-- /.card -->

<div class="row">
</div>
        <!-- /.card -->
<div class="row">
</div>
      
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php require_once("includes/footer.php"); ?>

  <!-- Control Sidebar -->
 
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<?php require_once("includes/javascript.php"); ?>


</body>
</html>
