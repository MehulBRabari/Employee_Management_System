<?php

// Connecting Database //
require_once('config/db_config.php');

// Current Time Zone //
date_default_timezone_set('Asia/Kolkata');
$date = date('Y-m-d H:i:sa');
// Checking session for employee id is created or not //
if ($_SESSION['subuser_emp_id'] == '') {
  header("location:login.php");
}

if (isset($_POST['submit'])) {
  // Current Time Stamp for Reminder Date //
  /*$reminder_date = date('d/m/Y');
  $reminder_date_explode = explode("/", $reminder_date);
  $reminderdate_explode = $reminder_date_explode['2'] . '-' . $reminder_date_explode['1'] . '-' . $reminder_date_explode['0'];*/
  
  $next_date = $_POST['reminder_date'];
  //exit;
  $desc = htmlspecialchars($_POST['reminder_description']);

  $reminder_sql = "INSERT into followup_history set indiamart_id='" . $_GET['indiamartid'] . "',followup_description='" . $desc . "',followup_date='" . $next_date . "',userid='".$_SESSION['subuser_admin_id']."',subuser_id='" . $_SESSION['subuser_emp_id'] . "',followup_status='1',followup_created_date_time='$date'";
  //exit;
  $remidner_que = mysqli_query($con, $reminder_sql);
/*  echo "<script> alert('Followup added successfully !!!');</script>";
  echo '<script type="text/javascript">window.location = "indiamart-manual-summary.php"</script>';*/
  
  $success = "success";
  header('refresh:1');
}

if (isset($_POST['close_followup'])) {
  // Current Time Stamp for Reminder Date //
  $reminder_close_date = $_POST['reminder_date'];

  $reminder_close_sql = "INSERT into followup_history set indiamart_id='" . $_GET['indiamartid'] . "',followup_description='" . $_POST['reminder_description'] . "',followup_date='" . $reminder_close_date . "',userid='".$_SESSION['subuser_admin_id']."',subuser_id='" . $_SESSION['subuser_emp_id'] . "',followup_status='2'";
  $remidner_close_que = mysqli_query($con, $reminder_close_sql);
  
  /*echo "<script> alert('Followup added successfully !!!');</script>";
  echo '<script type="text/javascript">window.location = "indiamart-manual-summary.php"</script>';*/
  
  $success2 = "success";
  header('refresh:1');
}


$get_id = $_GET['indiamartid'];

$select_query = "SELECT * FROM indiamart_summary WHERE indiamart_id = '$get_id'";

$run_query = mysqli_query($conn,$select_query);

$fetch_data = mysqli_fetch_array($run_query);

?>

<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Add Followup</title>

  <!---- Head Links ---->
  <?php require_once('head_links.php'); ?>

  <link rel="stylesheet" type="text/css" href="dist/css/bootstrap-datepicker.css">

</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">


    <!--- Preloader --->
    <?php require_once('pre_loader.php'); ?>

    <!--- Top Navbar --->
    <?php require_once('top_navbar.php'); ?>

    <!--- Left Navbar --->
    <?php require_once('left_navbar.php'); ?>

    <!--- Right Top Heading --->
    <?php require_once('right_top_heading.php'); ?>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <form method="POST">
          <div class="row">
            <div class="col-12" id="accordion">
            
            <!-- /.Success Alert Box -->
            <?php if (isset($success)) { ?>
              <div class="alert alert-success alert-dismissible">
                <i class="fa fa-spinner fa-spin" style="font-size:24px" ></i> Followup Added Successfully !!!
              </div>
            <?php } ?>

            <!-- /.Success Alert Box -->
            <?php if (isset($success2)) { ?>
              <div class="alert alert-success alert-dismissible">
                <i class="fa fa-spinner fa-spin" style="font-size:24px" ></i> Lead Closed Successfully !!!
              </div>
            <?php } ?>
            
              <div class="card card-success card-outline">
                <a class="d-block w-100" data-toggle="collapse" href="#collapseNine">
                  <?php
                  $follow_history_sql = "select * from subuser_login where subuser_id='".$_SESSION['subuser_emp_id']."'";
                  $follow_history_que = mysqli_query($con, $follow_history_sql);
                  $follow_history_fetch = mysqli_fetch_array($follow_history_que);
                  ?>
                  <div class="card-header">

                    <h4  class="float-left text-bold h5 text-danger">Followup By : <?php echo $follow_history_fetch['subuser_first_name'] . " " . $follow_history_fetch['subuser_last_name']; ?></h4>
                    <h4 class="float-left text-bold h5 text-danger">Mobile No :<?php echo $$fetch_data['mobile']; ?>
                    <a href="todays_followup.php" class="btn btn-default float-right"><i class="fa fa-backward"></i> Go Back</a>
                  </div>
                </a>
                <div id="collapseNine" class="collapse show" data-parent="#accordion" style="">
                  <div class="card-body">
                    <section class="content">
                      <div class="container-fluid">
                        <div class="row">
                          <?php if (!$_GET['followup_status']) { ?> 
                            
                            <div class="col-sm-6">
                                <div class="form-group">
                                  <label>Next Followup Date: <span style="color:red;">*</span></label>
                                    <div class="input-group date" id="reservationdate" data-target-input="nearest">
                                        <input type="date" min="<?php echo date('Y-m-d'); ?>" class="form-control" placeholder="Next Followup Date"  data-target="#reservationdate" name="reminder_date" autocomplete="off" required>
                                        <div class="input-group-append" data-target="#reservationdate" data-toggle="datetimepicker">
                                            <!-- <div class="input-group-text" ><i class="fa fa-calendar"></i></div> -->
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            <div class="col-sm-6"></div>
                            <div class="col-sm-6">
                              <div class="form-group">
                                <label>Current Followup Remarks: <span style="color:red;">*</span></label>
                                <div class="input-group">
                                  <textarea class="form-control" name="reminder_description" placeholder="Add Followup Remark" autocomplete="off" required cols="8" rows="4"></textarea>
                                </div>
                              </div>
                            </div>
                            
                            <div class="col-sm-6"></div>
                            <div class="col-sm-6">
                              <div class="form-group">
                                <input type="submit" class="btn" name="submit" value="Add Followup" style="background-color: #18486e;color:#fff;">
                                <input type="submit" class="btn btn-danger" name="close_followup" value="Close Query">
                                <!-- <a class="btn btn-default" onclick="window.history.go(-1); return false;"><i class="fa fa-backward"></i> Go Back</a> -->
                              </div>
                            </div>
                          <?php } ?>
                          

                          
                        </div>
                      </div>
                    </section>

                   

                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
      <!-- /.container-fluid -->
    </section>

                         <div class="col-12">
                            <div class="card">
                              <div class="card-body table-responsive p-3">
                                <table id="example1" class="table table-bordered table-striped table-sm" data-order='[[2,"desc"]]'>
                                  <thead>
                                    <tr class="text-center">
                                      <th>Sr.No</th>
                                      <th>Entry/Created Date Time</th>
                                      <th>Next Followup Date</th>
                                      <th>Description</th>
                                      <th>Followup By</th>
                                    </tr>
                                  </thead>
                                  <tbody class="text-center">
                                    <?php
                                    // Fetching followup history //
                                    $i = 0;
                                    $data_sql = "select * from followup_history INNER JOIN subuser_login ON followup_history.subuser_id=subuser_login.subuser_id where indiamart_id='" . $_GET['indiamartid'] . "'ORDER BY followup_history.followup_id DESC";
                                    $data_que = mysqli_query($con, $data_sql);
                                    while ($data_fetch = mysqli_fetch_array($data_que)) {
                                      $i++;
                                    ?>
                                      <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo $data_fetch['followup_created_date_time']; ?></td>
                                        <td><?php echo $data_fetch['followup_date']; ?></td>
                                        <td><?php echo $data_fetch['followup_description']; ?></td>
                                        <td><?php echo $data_fetch['subuser_first_name'] . " " . $data_fetch['subuser_last_name']; ?></td>
                                      </tr>
                                    <?php } ?>

                                  </tbody>
                                </table>
                              </div>
                            </div>
                          </div>

    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!---- Footer ---->
  <?php //require_once('footer.php'); 
  ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!---- Script Links ---->
  <?php require_once('script_links.php'); ?>


 <!-- jQuery -->
<!-- <script src="plugins/jquery/jquery.min.js"></script> -->
<!-- Bootstrap 4 -->
<!-- <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script> -->
<!-- Select2 -->
<!-- <script src="plugins/select2/js/select2.full.min.js"></script> -->
<!-- Bootstrap4 Duallistbox -->
<!-- <script src="plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script> -->
<!-- InputMask -->
<!-- <script src="plugins/moment/moment.min.js"></script> -->
<!-- <script src="plugins/inputmask/jquery.inputmask.min.js"></script> -->
<!-- date-range-picker -->
<!-- <script src="plugins/daterangepicker/daterangepicker.js"></script> -->
<!-- bootstrap color picker -->
<!-- <script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script> -->
<!-- Tempusdominus Bootstrap 4 -->
<!-- <script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script> -->
<!-- Bootstrap Switch -->
<!-- <script src="plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script> -->
<!-- BS-Stepper -->
<!-- <script src="plugins/bs-stepper/js/bs-stepper.min.js"></script> -->
<!-- dropzonejs -->
<!-- <script src="plugins/dropzone/min/dropzone.min.js"></script> -->
<!-- AdminLTE App -->
<!-- <script src="dist/js/adminlte.min.js"></script> -->

<!-- Page specific script -->
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Date picker
    $('#reservationdate').datetimepicker({
        format: 'L'
    });

    //Date and time picker
    $('#reservationdatetime').datetimepicker({ icons: { time: 'far fa-clock' } });

    //Date range picker
    //Date range picker
    $('#reservation').daterangepicker({
      locale: {
        format: 'YYYY/MM/DD'
      }
    })
  })

</script>
</body>
</html>