<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
      <img src="../dist/img/codeinweblogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">User</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      
      <!-- SidebarSearch Form -->
      <div class="form-inline">
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'user_dashboard.php' ? 'menu-open' : ''; ?>">
            <a href="user_dashboard.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'user_dashboard.php' ? 'active' : ''; ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
                <!-- <i class="right fas fa-angle-left"></i> -->
              </p>
            </a>
          </li>
      
          <li class="nav-item <?php echo in_array(basename($_SERVER['PHP_SELF']), ['all_emp_profile.php']) ? 'menu-open' : ''; ?>">
            <a href="#" class="nav-link <?php echo in_array(basename($_SERVER['PHP_SELF']), ['all_emp_profile.php']) ? 'active' : ''; ?>">
              <i class="fas fa-users ml-1 style=font-size:15px;"></i>
              <!-- <i class="nav-icon fas fa-copy"></i> -->
              <p class="ml-2">
                Employees
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="all_emp_profile.php" class="nav-link <?php  echo basename($_SERVER['PHP_SELF']) == 'all_emp_profile.php' ? 'active' : ''; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>All Employee</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'emp_salary_sleep.php' ? 'menu-open' : ''; ?>">
            <a href="#" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'emp_salary_sleep.php' ? 'active' : ''; ?>">
              <i class="nav-icon fas fa-table"></i>
              <p>
              Salary
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="emp_salary_sleep.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'emp_salary_sleep.php' ? 'active' : ''; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Salary Sleep</p>
                </a>
              </li>
            </ul>
          </li>

          <li class="nav-item <?php echo in_array(basename($_SERVER['PHP_SELF']), ['emp_leave_history.php']) ? 'menu-open' : ''; ?>">
            <a href="#" class="nav-link <?php echo in_array(basename($_SERVER['PHP_SELF']), ['emp_leave_history.php']) ? 'active' : ''; ?>">
            <i class="nav-icon fas fa-tree"></i> 
            <p>
              Employee Leave  
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="emp_leave_history.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'emp_leave_history.php' ? 'active' : ''; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Leave History</p>
                </a>
              </li>
            </ul>
          </li>
           


          <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'user_holiday_schedule.php' ? 'menu-open' : ''; ?>">
            <a href="#" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'user_holiday_schedule.php' ? 'active' : ''; ?>">
               <i class="nav-icon far fa-calendar-alt"></i>
              <p>
               Event And Holiday
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="user_holiday_schedule.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'user_holiday_schedule.php' ? 'active' : ''; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Calender</p>
                </a>
              </li>
            </ul>
          </li>
  
          <!-- <li class="nav-header">EXAMPLES</li> -->
         
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>