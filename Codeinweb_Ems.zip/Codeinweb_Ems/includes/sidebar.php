<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
      <img src="dist/img/codeinweblogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">Admin</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      
      <!-- SidebarSearch Form -->
      <div class="form-inline">
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'menu-open' : ''; ?>">
            <a href="admin_dashboard.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_dashboard.php' ? 'active' : ''; ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
                <!-- <i class="right fas fa-angle-left"></i> -->
              </p>
            </a>
          </li>
      
          <li class="nav-item <?php echo in_array(basename($_SERVER['PHP_SELF']), ['add_emp.php', 'manage_all_emp.php']) ? 'menu-open' : ''; ?>">
            <a href="#" class="nav-link <?php echo in_array(basename($_SERVER['PHP_SELF']), ['add_emp.php', 'manage_all_emp.php']) ? 'active' : ''; ?>">
              <!-- <i class="nav-icon fas fa-copy"></i> -->
              <i class="fas fa-users ml-1" style="font-size:15px;"></i>
              <p class="ml-2">
                Employees
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="add_emp.php" class="nav-link <?php  echo basename($_SERVER['PHP_SELF']) == 'add_emp.php' ? 'active' : ''; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add New Employee</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="manage_all_emp.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_all_emp.php' ? 'active' : ''; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Manage All Employee</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'manage_all_emp_salary.php' ? 'menu-open' : ''; ?>">
            <a href="#" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_all_emp_salary.php' ? 'active' : ''; ?>">
              <i class="nav-icon fas fa-table"></i>
              <p>
              Salary
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="manage_all_emp_salary.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_all_emp_salary.php' ? 'active' : ''; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Manage Employee Salary</p>
                </a>
              </li>
            </ul>
          </li>

          <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'manage_emp_leave.php' ? 'menu-open' : ''; ?>">
            <a href="#" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_emp_leave.php' ? 'active' : ''; ?>">
              <i class="nav-icon fas fa-tree"></i>
              <!-- <i class="fa-solid fa-person-walking-arrow-right"></i> -->
              <p>
               Leave Management
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="manage_emp_leave.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'manage_emp_leave.php' ? 'active' : ''; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Leave History</p>
                </a>
              </li>
            </ul>
          </li>


          <li class="nav-item <?php echo basename($_SERVER['PHP_SELF']) == 'admin_holiday_schedule.php' ? 'menu-open' : ''; ?>">
            <a href="#" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_holiday_schedule.php' ? 'active' : ''; ?>">
               <i class="nav-icon far fa-calendar-alt"></i>
              <p>
               Event And Holiday
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="admin_holiday_schedule.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_holiday_schedule.php' ? 'active' : ''; ?>">
                <i class="far fa-circle nav-icon"></i>
                  <p>Calender</p>
                </a>
              </li>
            </ul>
          </li>
  
          <!-- <li class="nav-header">EXAMPLES</li> -->
         
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>