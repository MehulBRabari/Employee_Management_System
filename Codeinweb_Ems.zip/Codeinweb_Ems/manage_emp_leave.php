<?php require_once('config/connection.php'); ?>
<?php 
if ($_SESSION['admin_id'] == '')
{
	header('location:index.php');
}

$select_query = "SELECT * FROM add_employee";
 
 $result = mysqli_query($conn,$select_query);
 
 $fetch_data = mysqli_fetch_array($result);

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>All Employee Leave Data | codeinweb Technologies</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  
  <!-- <link rel="stylesheet" type="text/css" href="dist/css/all.min.css"> -->


<!-- Favicon icon -->
<link rel="icon" type="image/x-icon" href="dist/img/codeinweblogo.png" />

</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
 <?php require_once('includes/topnavbar.php'); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
 <?php require_once('includes/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Employee Leave </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <!-- <li class="breadcrumb-item"><a href="#">Home</a></li> -->
              <li class="breadcrumb-item active">Leave Tables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->
            <div class="card card-primary card-outline">
              <div class="card-header">
                <h3 class="card-title">Employee Leave DataTable</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Emp Id</th>
                    <th>Name</th>
                    <th>Leave Type</th>
                    <th>Leave Date</th>
                    <!-- <th>Leave Duration</th> -->
                    <th>From</th>
                    <th>To</th>
                    <th>Status</th>
                    <th>Leave Description</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>

                  <!-- SELECT QUERY FROM EMP LEAVE  -->

                    <?php 
                    $select_query = "SELECT * FROM emp_leave";
                    $result = mysqli_query($conn,$select_query);
                    while($value = mysqli_fetch_array($result))
                    {
                    ?>
                  <tr>
                    <td><?php echo $value['employeeID']; ?></td>
                    <td><?php echo $value['emp_name']; ?></td>
                    <td><?php echo $value['select_leave']; ?></td>
                    <td><?php echo $value['single_date']; ?></td>
                    <!-- <td><?php echo $value['leave_duration']; ?></td> -->
                    <td><?php echo $value['from_date']; ?></td>
                    <td><?php echo $value['to_date']; ?></td>
                    <td><?php 
                         if($value['status'] == '1')
                         {
                          echo '<span><a href="leave_status.php?Employee_id='.$value['id'].'&status=0" class="btn btn-success btn-sm">Approved</a></span>';
                         }
                         else 
                         {
                          echo '<p><a href="leave_status.php?Employee_id='.$value['id'].'&status=1" class="btn btn-danger btn-sm">Panding</a></p>';
                         }
                     ?></td>
                    <td><?php echo $value['leave_description']; ?></td>

                    <td class="project-actions text-right">
                          <a class="btn btn-info btn-sm" href="edit_emp_leave.php?edit_leave=<?php echo $value['id']; ?>" title="Edit Data"><i class="fas fa-pencil-alt"></i></a>
                          <a class="btn btn-danger btn-sm" href="delete_leave.php?delete_leave=<?php echo $value['id']; ?>" onclick="return confirm('Are you sure delete item');" title="Delete Data"><i class="fas fa-trash"></i></a>
                    </td>
                  </tr>
                  <?php } ?>
                  </tbody>
                  <tfoot>    
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 

<?php require_once('includes/footer.php'); ?> 
  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<?php require_once('includes/javascript.php'); ?>

</body>
</html>
