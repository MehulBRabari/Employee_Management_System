<?php require_once('config/connection.php'); ?>
<?php
$get_id = $_GET['delete_data'];

$delete_query = "DELETE FROM employee_salary WHERE id = '$get_id'";

$run_delete_query = mysqli_query($conn,$delete_query);

if($run_delete_query)
{
    $success = 'success';
    header("refresh:2;URL='manage_all_emp_salary.php");

}
else
{
    $fail = 'fail';
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>All Employee Salary Data | Codeinweb Technologies</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link rel="stylesheet" type="text/css" href="dist/css/all.min.css">


<!-- Favicon icon -->
<link rel="icon" type="image/x-icon" href="dist/img/codeinweblogo.png" />

</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
 <?php require_once('includes/topnavbar.php'); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
 <?php require_once('includes/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Employee Salary</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Salary Tables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        
<?php if(isset($success))
{ ?>
<div class = "alert alert-success alert-dismissible" style="font-size:20px" >
<i class = "fa fa-spinner fa-spin"></i>DATA DELETE SUCCESSFUL !! 
</div>
<?php } ?>

<?php if(isset($fail))  
{ ?>
<div class = "alert alert-danger alert-dismissible" style="font-size:20px" >
<i class = "icon fa fas-ban"></i> DATA NOT DELETED</div>
  <?php } ?>

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Employee Salary DataTable</h3>
                <a class="btn btn-sm btn-primary float-right" href="emp_pay_salary.php?pay_amount=<?php echo $fetch_data['id']; ?>" title="Employee Pay Amount"><i class="fas fa-plus"></i>Add Salary</a>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Employee Id</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Date Of Salary</th>
                    <!-- <th>Salary Amount</th> -->
                    <th>Remark</th>
                    <th>Action </th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                   $select_query = "SELECT * FROM employee_salary";                    
                   $result = mysqli_query($conn,$select_query);
                    while($value = mysqli_fetch_array($result))
                    {
                    ?>
                  <tr>
                    <td><?php echo $value['employeeID']; ?></td>
                    <td><?php echo $value['first_name']; ?></td>
                    <td><?php echo $value['last_name']; ?></td>
                    <td><?php echo $value['date']; ?></td>
                    <td><?php echo $value['remark']; ?></td>
                    <td class="project-actions text-right">
                          <a class="btn btn-info btn-sm" href="edit_emp_salary.php?edit_data=<?php echo $value['id']; ?>" title="Edit Data"><i class="fas fa-pencil-alt"></i></a>
                          <a class="btn btn-danger btn-sm" href="delete_emp_salary.php?delete_data=<?php echo $value['id']; ?>" onclick="return confirm('Are you sure delete item');" title="Delete Data"><i class="fas fa-trash"></i></a>
                    </td>
                  </tr>
                  <?php } ?>
                  </tbody>
                  <tfoot>
                 
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 
<?php require_once('includes/footer.php'); ?>
  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<?php require_once('includes/javascript.php'); ?>

</body>
</html>
