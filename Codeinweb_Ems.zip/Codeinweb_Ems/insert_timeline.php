<?php
require_once('config/connection.php');

// $get_id = $_GET['view_data'];

// $select_query = "SELECT * FROM add_employee WHERE id = '$get_id'";
// $run_select_query = mysqli_query($conn, $select_query);
// $fetch_data = mysqli_fetch_array($run_select_query);

if ($_SESSION['admin_id'] == '')
{
	header('location:index.php');
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $join_date = $_POST['join_date'];
    $designation = $_POST['designation'];
    $work_description = $_POST['work_description'];
    $first_pro_date = $_POST['first_pro_date'];
    $first_pro_review = $_POST['first_pro_review'];
    $lead_new_pro = $_POST['lead_new_pro'];
    $perform_review = $_POST['perform_review'];
    $promotion_date = $_POST['promotion_date'];
    $promotion_dep = $_POST['promotion_dep'];



    $insert_timeline_query = "INSERT INTO employee_timeline(employee_id, join_date, designation, work_description, first_pro_date,first_pro_review,lead_new_pro,perform_review,promotion_date,promotion_dep) VALUES('$get_id', '$join_date', '$designation', '$work_description','$first_pro_date','$first_pro_review','$lead_new_pro','$perform_review','$promotion_date','$promotion_dep')";    
    mysqli_query($conn, $insert_timeline_query);


}
// } elseif (isset($_POST['delete_event'])) {
//   $event_id = $_POST['event_id'];

//   $delete_timeline_query = "DELETE FROM employee_timeline WHERE id = '$event_id'";
//   mysqli_query($conn, $delete_timeline_query);
// }



?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Employee Profile | codeinweb Technologies</title>
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link rel="icon" type="image/icon/x" href="dist/img/codeinweblogo.png">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
 <?php require_once('includes/topnavbar.php'); ?>
  <!-- Main Sidebar Container -->
  <?php require_once('includes/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Profile</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">User Profile</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3">
            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle"
                       src="uploaded_images/<?php echo $fetch_data['emp_image'] ?>"
                      style="height:150px; width:250px;" alt="User profile picture">
                </div>
                <h3 class="profile-username text-center"><?php echo $fetch_data['first_name']; ?> <?php echo $fetch_data['last_name']; ?></h3>
                <p class="text-muted text-center"><?php echo $fetch_data['designation']?></p>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            <!-- About Me Box -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">About Me</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <strong><i class="fas fa-book mr-1"></i> Position</strong>
                <p class="text-muted"><?php echo $fetch_data['position']; ?></p>
                <hr>
                <strong><i class="fas fa-map-marker-alt mr-1"></i> Location</strong>
                <p class="text-muted"><?php echo $fetch_data['address']; ?></p>
                <hr>
                <strong><i class="far fa-file-alt mr-1"></i>Experience</strong>
                <p class="text-muted"><?php echo $fetch_data['experience']; ?></p>
                <hr>
                <strong><i class="fas fa-pencil-alt mr-1"></i>Other Info</strong>
                <p class="text-muted">
                  <span class="tag tag-danger">Mobile No:- <?php echo $fetch_data['mobile']; ?></span><br>
                  <span class="tag tag-success">Emergency No: <?php echo $fetch_data['emobile']; ?></span><br>
                  <span class="tag tag-info">Email Id: <?php echo $fetch_data['email']; ?></span>
                </p>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-md-9">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item"><a class="nav-link active" href="#activity" data-toggle="tab">Activity</a></li>
                  <li class="nav-item"><a class="nav-link" href="#timeline" data-toggle="tab">Timeline</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="active tab-pane" id="activity">
                    <div class="card">
                      <div class="card-header">
                        <h3 class="card-title">Employee Details</h3>
                      </div>
                      <div class="card-body p-0">
                        <table class="table">
                          <thead>
                            <tr>
                              <th>Label</th>
                              <th>Data</th>
                              <th></th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr><td><b>Employee Name:</b></td><td><?php echo $fetch_data['first_name']; ?> <?php echo $fetch_data['last_name']; ?></td></tr>
                            <tr><td><b>Date Of Birth:</b></td><td><?php echo $fetch_data['dob']; ?></td></tr>
                            <tr><td><b>Mobile No:</b></td><td><?php echo $fetch_data['mobile']; ?></td></tr>
                            <tr><td><b>Emergency Mobile No:</b></td><td><?php echo $fetch_data['emobile']; ?></td></tr>
                            <tr><td><b>Email:</b></td><td><?php echo $fetch_data['email']; ?></td></tr>
                            <tr><td><b>Designation:</b></td><td><?php echo $fetch_data['designation']; ?></td></tr>
                            <tr><td><b>Position:</b></td><td><?php echo $fetch_data['position']; ?></td></tr>
                            <tr><td><b>Experience:</b></td><td><?php echo $fetch_data['experience']; ?></td></tr>
                            <tr><td><b>Address:</b></td><td><?php echo $fetch_data['address']; ?></td></tr>
                            <tr><td><b>Joining Date:</b></td><td><?php echo $fetch_data['joining_date']; ?></td></tr>
                            <tr>
                              <td>
                                <a class="btn btn-primary btn-sm" href="edit_emp_data.php?edit_data=<?php echo $fetch_data['id']; ?>" title="Edit Data"><i class="fas fa-pencil-alt"></i> Edit</a>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="timeline">
                    <!-- Add New Timeline Event Form -->
                    <div class="card">
                      <div class="card-header">
                        <h3 class="card-title">Add New Timeline Event</h3>
                      </div>
                      <div class="card-body">
                        <form method="post" action="">
                          <div class="form-group">
                            <label for="join_date">Joining Date</label>
                            <input type="date" class="form-control" id="join_date" name="join_date" required>
                          </div>
                          <div class="form-group">
                            <label for="designation">Designation</label>
                            <input type="text" class="form-control" id="designation" name="designation" required>
                          </div>
                          <div class="form-group">
                            <label for="work_description">Work Description</label>
                            <input type="text" class="form-control" id="work_description" name="work_description" required>
                          </div>
                          <div class="form-group">
                            <label for="first_pro_date">First Project Assign Date</label>
                            <input type="date" class="form-control" id="first_pro_date" name="first_pro_date" required>
                          </div>

                          <div class="form-group">
                            <label for="first_pro_review">First Project Assign Review</label>
                            <textarea type="text" class="form-control" id="first_pro_review" name="first_pro_review" required></textarea>
                          </div>

                          <div class="form-group">
                            <label for="lead_new_pro">Lead New Project Review</label>
                            <textarea type="text" class="form-control" id="lead_new_pro" name="lead_new_pro" required></textarea>
                          </div>

                          <div class="form-group">
                            <label for="perform_review">Performance Review</label>
                            <textarea type="text" class="form-control" id="perform_review" name="perform_review" required></textarea>
                          </div>
                          
                          <div class="form-group">
                            <label for="promotion_date">Promotion Date</label>
                            <input type="date" class="form-control" id="promotion_date" name="promotion_date" required>
                          </div>

                          <div class="form-group">
                            <label for="promotion_dep">Promotion Department</label>
                            <input type="text" class="form-control" id="promotion_dep" name="promotion_dep" required>
                          </div>

                          <button type="submit" class="btn btn-primary">Add Timeline</button>
                                               
                        </form>
                      </div>
                    </div>

                    <!-- The timeline -->
                    <div class="timeline timeline-inverse">
                      <?php
                      $timeline_query = "SELECT * FROM employee_timeline WHERE employee_id = '$get_id' ORDER BY join_date DESC";
                      $run_timeline_query = mysqli_query($conn, $timeline_query);
                      while ($timeline_data = mysqli_fetch_array($run_timeline_query)) {
                      ?>
                        <div class="time-label">
                          <span class="bg-success">
                            <?php echo date('d M. Y', strtotime($timeline_data['join_date'])); ?>
                          </span>
                        </div>
                        <div>
                          <i class="fas fa-user bg-info"></i>
                          <div class="timeline-item">
                            <span class="time"><i class="far fa-clock"></i> <?php echo date('H:i', strtotime($timeline_data['join_date'])); ?></span>
                            <h3 class="timeline-header"><a href="#"><?php echo $timeline_data['designation']; ?></a></h3>
                            <div class="timeline-body">
                              <?php echo $timeline_data['work_description']; ?>
                            </div>
                          </div>
                        </div>
                        <div class="time-label">
                        <span class="bg-danger">
                        <?php echo date('d M. Y', strtotime($timeline_data['first_pro_date'])); ?>
                        </span>
                      </div>
                      <div>
                          <i class="fas fa-user bg-info"></i>
                          <div class="timeline-item">
                            <span class="time"><i class="far fa-clock"></i> <?php echo date('H:i', strtotime($timeline_data['join_date'])); ?></span>
                            <h3 class="timeline-header"><a href="#"><?php echo $timeline_data['first_pro_review']; ?></a></h3>
                            <!-- <div class="timeline-body">
                              <?php echo $timeline_data['work_description']; ?>
                            </div> -->
                          </div>
                        </div>
                        
                        <div class="timeline-item">
                            <!-- <span class="time"><i class="far fa-clock"></i> <?php echo date('H:i', strtotime($timeline_data['join_date'])); ?></span> -->
                            <!-- <h3 class="timeline-header"><a href="#"><?php echo $timeline_data['lead_new_pro']; ?></a></h3> -->
                            <!-- <div class="timeline-body">
                    
                            </div> -->
                        </div>

                        <div class="time-label">
                        <span class="bg-primary">
                        <?php echo date('d M. Y', strtotime($timeline_data['promotion_date'])); ?>
                        </span>
                      </div>

                        <div>
                        <i class="fa-solid fa-user-shield"></i>
                          <!-- <i class="fas fa-user bg-info"></i> -->
                          <div class="timeline-item">
                            <span class="time"><i class="far fa-clock"></i> <?php echo date('H:i', strtotime($timeline_data['join_date'])); ?></span>
                            <h3 class="timeline-header"><a href="#"><?php echo $timeline_data['promotion_dep']; ?></a></h3>
                            <!-- <div class="timeline-body">
                              <?php echo $timeline_data['work_description']; ?>
                            </div> -->
                          </div>
                        </div>

                      <?php
                      }
                      ?>
                      <div>
                        <i class="far fa-clock bg-gray"></i>
                      </div>
                    </div>
                  </div>
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div><!-- /.card -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php require_once('includes/footer.php'); ?>
  <!-- Control Sidebar -->
  <?php require_once('includes/javascript.php'); ?>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
</body>
</html>
