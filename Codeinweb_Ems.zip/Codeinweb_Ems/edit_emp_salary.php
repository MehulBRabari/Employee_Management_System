<?php require_once('config/connection.php'); ?>

<?php

if ($_SESSION['admin_id'] == '')
{
	header('location:index.php');
}


$get_id = $_GET['salary_id'];

$select_query = "SELECT * FROM employee_salary WHERE id = '$get_id'";

$run_query = mysqli_query($conn,$select_query);

$fetch_data = mysqli_fetch_array($run_query);

if(isset($_POST['update']))
{
  // $first_name = $_POST['first_name'];
  // $last_name = $_POST['last_name'];
  $date = $_POST['date'];
  $pay_period = $_POST['pay_period'];
  $worked_days = $_POST['worked_days'];
  $basic_pay = $_POST['basic_pay'];
  $incentive_pay = $_POST['incentive_pay'];
  $house_rent_allowance = $_POST['house_rent_allowance'];
  $meal_allowance = $_POST['meal_allowance'];
  $provident_fund = $_POST['provident_fund'];
  $professional_tax = $_POST['professional_tax'];
  $loan = $_POST['loan'];
  // $amount = $_POST['amount'];
  $remark = $_POST['remark'];

$update_query = "UPDATE employee_salary SET date = '$date', pay_period= '$pay_period', worked_days = '$worked_days', basic_pay = '$basic_pay', incentive_pay = '$incentive_pay', house_rent_allowance = '$house_rent_allowance', meal_allowance = '$meal_allowance', provident_fund = '$provident_fund', professional_tax = '$professional_tax' ,loan = '$loan',  remark = '$remark' WHERE id = '$get_id'";   

$run_update_query = mysqli_query($conn,$update_query);
  
  if($run_update_query)
  {
      $success = "success";
      header('refresh:2;URL=manage_all_emp_salary.php');
  }
  else
  {
      $fail = "fail";
  }
}

?> 


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Edit Employee Salary | Codeinweb Technologies</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

  <link rel="icon" type="image/icon/x" href="dist/img/codeinweblogo.png">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
<?php require_once('includes/topnavbar.php'); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php require_once('includes/sidebar.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Salary Form</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <!-- <li class="breadcrumb-item"><a href="#">Home</a></li> -->
              <li class="breadcrumb-item active">Update Salary Form</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary card-outline">
            <?php if (isset($success)) { ?>
             <div class="alert alert-success alert-dismissible" style="font-size:20px">
                <i class="fa fa-spinner fa-spin" ></i> Update Salary Employee !!!
              </div>
              <?php } ?>

<!-- /.Fail Alert Box -->
            <?php if (isset($fail)) { ?>
            <div class="alert alert-danger alert-dismissible" style="font-size: 17px">
               <i class="icon fas fa-ban"></i> Salary Not Update !!!
              </div>
             <?php } ?>
              <div class="card-header">
                <h3 class="card-title">Update Salary</h3>
                <a class="btn btn-dark  float-right" onclick="window.history.go(-1); return false;"><i class="fa fa-backward"></i> Go Back</a>

              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="" method="post">
                <div class="card-body">
                  <div class="row">
                  <div class="col-md-6">
                  
                  </div>

                  <div class="col-md-6">
                  
                  </div>
                  
                  <div class="col-md-6">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Salary Date</label>
                    <input type="Date" name="date" value="<?php echo $fetch_data['date']; ?>" class="form-control" id="exampleInputPassword1" placeholder="Date">
                  </div>
                  </div>

                  <div class="col-md-6">
                  <div class="form-group">
                    <label>Pay Period</label>
                    <input type="text" name="pay_period" value="<?php echo $fetch_data['pay_period']; ?>" class="form-control" placeholder="Pay Period" required>
                  </div>
                  </div>
                   
                  <div class="col-md-6">
                  <div class="form-group">
                    <label>Worked Days</label>
                    <input type="number" name="worked_days" value="<?php echo $fetch_data['worked_days']; ?>" class="form-control" placeholder="Worked Days" required>
                  </div>
                  </div>

                  <div class="col-md-6">
                  <div class="form-group">
                    <label>Basic Pay</label>
                     <input type="number" name="basic_pay" value="<?php echo $fetch_data['basic_pay']; ?>" class="form-control" placeholder="Basic Pay" required>
                  </div>
                  </div>

                  <div class="col-md-6">
                  <div class="form-group">
                    <label>Incentive Pay</label>
                     <input type="number" name="incentive_pay" value="<?php echo $fetch_data['incentive_pay']; ?>" class="form-control" placeholder="Incentive Pay" required>
                  </div>
                  </div>

                  <div class="col-md-6">
                  <div class="form-group">
                    <label>House Rent Allowance</label>
                     <input type="number" name="house_rent_allowance" value="<?php echo $fetch_data['house_rent_allowance']; ?>" class="form-control" placeholder="House Rent Allowance" required>
                  </div>
                  </div>
                  
                  <div class="col-md-6">
                  <div class="form-group">
                    <label>Meal Allowance</label>
                     <input type="number" name="meal_allowance" value="<?php echo $fetch_data['meal_allowance']; ?>" class="form-control" placeholder="Meal Allowance" required>
                   </div>
                   </div>

                   <div class="col-md-6">
                   <div class="form-group">
                    <label>Provident Fund</label>
                     <input type="number" name="provident_fund" value="<?php echo $fetch_data['provident_fund']; ?>" class="form-control" placeholder="Provident Fund" required>
                  </div>
                   </div>

                  <div class="col-md-6">
                  <div class="form-group">
                    <label>Professional Text</label>
                    <input type="number" name="professional_tax" value="<?php echo $fetch_data['professional_tax']; ?>" class="form-control" placeholder="Professional Tax" required>
                  </div>
                  </div>

                  <div class="col-md-6">
                  <div class="form-group">
                    <label>Loan</label>
                     <input type="number" name="loan" value="<?php echo $fetch_data['loan']; ?>" class="form-control" placeholder="Loan" required>
                  </div>
                 </div>
                  
                 <div class="col-md-6">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Remark</label>
                    <input type="text" value=<?php echo $fetch_data['remark']; ?> class="form-control" name="remark">
                        
                  </div>
                   </div>

                   <div class="col-md-12">
                  <div class="form-group">
                  <button type="submit" name="update" class="btn btn-primary">Update</button>
                  </div>
                  </div>

                  <!-- <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                    <label class="form-check-label" for="exampleCheck1">Check me out</label>
                  </div> -->
               
                </div>
                <!-- /.card-body -->

                <!-- <div class="card-footer">
                  <button type="submit" name="update" class="btn btn-primary">Update</button>
                </div> -->

                   </div>
              </form>
            </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 <?php require_once('includes/footer.php'); ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<?php require_once('includes/javascript.php'); ?>
<!-- jQuery -->

</body>
</html>
