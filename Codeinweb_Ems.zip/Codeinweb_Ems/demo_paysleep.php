<?php

  // Connecting Database //
  require_once('config/connection.php');

  // Checking session for employee id is created or not //
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Manual Email</title>
  <!-- Favicon -->
  <link rel="ICON" href="dist/img/icon.png" type="image/png" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
<link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
<link rel="stylesheet" href="plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css">
<link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
<link rel="stylesheet" href="plugins/select2/css/select2.min.css">
<link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
<link rel="stylesheet" href="plugins/select2/css/select2.min.css">
<link rel="stylesheet" href="plugins/bootstrap4-duallistbox/bootstrap-duallistbox.min.css">
<link rel="stylesheet" href="plugins/bs-stepper/css/bs-stepper.min.css">
<link rel="stylesheet" href="plugins/dropzone/min/dropzone.min.css">
<link rel="stylesheet" href="dist/css/adminlte.min.css?v=3.2.0">
<link rel="stylesheet" type="text/css" href="dist/css/bootstrap-datepicker.css">
<link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
<link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
<link href="dist/css/Switch.css" rel="stylesheet"/>
<!-- Loader Css -->
<link rel="stylesheet" type="text/css" href="dist/css/spinner.css">

  <!---- Head Links ---->
  <?php //require_once('head_links.php'); ?>

</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!---- Preloader ---->


  <!---- Top Navbar ---->
  <?php require_once('includes/topnavbar.php'); ?>

  <!---- Left Navbar ---->
  <?php require_once('includes/sidebar.php'); ?>

  
  <!---- Left Navbar ---->
  

  <!-- Main content -->
    <div class="container-fluid">
      <!-- SELECT2 EXAMPLE -->
      <div class="card card-success card-outline">
        <section class="content">
        <?php if (isset($data_success)) { ?>
          <div class="alert alert-success alert-dismissible">
            <i class="fa fa-spinner fa-spin" style="font-size:24px"></i>Mail sent successfully !!!
          </div>
        <?php } ?>
        <div class="card-header">
          <h3 class="card-title" style="color:#17a2b8 !important;">Send Manual Email</h3>
          <!-- <button onclick="history.back()" class="btn btn-md btn-primary" style="float:right;">Go Back</button> -->
<a class="btn btn-default float-right" onclick="window.history.go(-1); return false;"><i class="fa fa-backward"></i> Go Back</a>
          
        </div>
        <!-- /.card-header -->
        <form method="post" enctype="multipart/form-data">
          <div class="card-body">
            <div class="row">
              <div class="col-md-4">
                    <div class="form-group">
                      <label>Sending email To <span style="color:red;">*</span></label>
                      <input type="text" class="form-control" placeholder="Receiver Email" name="sender_email" value="<?php echo $indiamart_fetch['email']; ?>" readonly>
                    </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Email Subject<span style="color:red;">*</span></label>
                  <input type="text" class="form-control" placeholder="Email Subject" name="email_subject" required>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Email Attachment (PDF file only)</label>
                  <div class="input-group mb-3">
                    <input type="file" class="form-control" name="file" id="file">
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                    <label>Email Message<span style="color:red;">*</span></label>
                    <textarea id="summernote" class="form-control" name="email_body">Enter your email description here....</textarea>
                </div>
            </div>
            </div>
            <!-- /.row -->
            <input type="submit" class="btn btn-md btn-primary" name="submit" value="Send Email">
          </div>
          <!-- /.card-body -->
        </form>
        </section>
      </div>
      <!-- /.card -->
      
      
      <!---- Data Tables Grid ---->
      <div class="card card-success card-outline">
      <?php if (isset($update)) { ?>
          <div class="alert alert-danger alert-dismissible">
            <i class="fa fa-spinner fa-spin" style="font-size:24px"></i> Something went wrong !!!
          </div>
        <?php } ?>
        <div class="card-header">
          <h3 class="card-title" style="color:#17a2b8 !important;">Previous Email Summary</h3>
        </div>
        <!-- /.card-body -->
        <div class="card-body">

          <!-- Adding Button -->
          <!--<a href="add-users.php" class="btn btn-primary"><i class="fas fa-plus"></i> Add New</a><br><br>-->
            <table id="example1" class="table table-bordered table-striped table-sm">
              <thead class="text-center">
                <tr>
                  <th>Sr.No.</th>
                  <th>Subject</th>
                  <th>Message</th>
                  <th>Attachment</th>
                  <th>Send Date/Time</th>
                </tr>
              </thead>
              <tbody class="text-center">
                <?php
                //echo $id = md5($_GET['india_actual_id']);
                // Fetching users Name //
                $user_sql = "select * from email_summary where indiamart_id='".$_GET['india_actual_id']."'";
                $user_que = mysqli_query($con, $user_sql);
                $i = 0;
                while ($user_fetch = mysqli_fetch_array($user_que)) {
                  $i++;
                  //$message = htmlentities($user_fetch['email_body']);
                ?>
                  <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $user_fetch['email_subject']; ?></td>
                    <td><?php  echo $user_fetch['email_body']; ?></td>
                    <td><?php if($user_fetch['email_attachment'] == ""){ echo "No Attachment"; }else{ ?> <a href="uploads/<?php echo $user_fetch['email_attachment']; ?>"><?php echo $user_fetch['email_attachment']; ?></a><?php } ?></td>
                    <td><?php echo $user_fetch['email_sent_date_time']; ?></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.Data Tables Grid -->
    </div>
    <!-- /.container-fluid -->

  <!---- Footer ---->
  <?php require_once('includes/footer.php'); ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

  <!---- Script Links ---->
  <?php require_once('includes/javascript.php'); ?>

  <script src="dist/js/bootstrap-datepicker.js"></script>


  <script src="plugins/summernote/summernote-bs4.min.js"></script>
  <script>
    // Summernote
    $('#summernote').summernote()

    // CodeMirror
    CodeMirror.fromTextArea(document.getElementById("codeMirrorDemo"), {
      mode: "htmlmixed",
      theme: "monokai"
    });
  </script>
</body>
</html>