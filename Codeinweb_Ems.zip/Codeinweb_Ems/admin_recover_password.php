<?php
require 'config/connection.php';


if(isset($_POST['update']))
{
	$newpass = md5($_POST['newpass']);
	$confirmpass = md5($_POST['cpass']);

if($newpass == $confirmpass)
{
	$query = "UPDATE admin_login SET password = '$confirmpass' WHERE email='".$_SESSION['email']."'";
	$forgate_pass = mysqli_query($conn,$query);

    $success = "success";
    header('refresh:2;URL=index.php');
}
else
{
    $fail = "fail";	
}
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Recover Password | codeinweb Technologies</title>

  <style>
    body {
    
      background-image:url('dist/img/background.jpg');
      background-repeat: no-repeat;
      background-size: cover;
      background-position: center center;
    
  }
    </style>



  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

  <link rel="icon" type="image/x-icon" href="dist/img/codeinweblogo.png">

</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
  <img src="dist/img/codeinweb.png" height="70" width="230">
  </div>

  <?php if (isset($success)) { ?>
  <div class="alert alert-success alert-dismissible" style="font-size:20px">
    <i class="fa fa-spinner fa-spin" ></i> Your Password is update successfully  !!!
  </div>
<?php } ?>

<!-- /.Fail Alert Box -->
<?php if (isset($fail)) { ?>
  <div class="alert alert-danger alert-dismissible" style="font-size: 17px">
    <i class="icon fas fa-ban"></i>  Your password is not update !!!
  </div>
<?php } ?>

  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">You are only one step a way from your new password, recover your password now.</p>

      <form action="" method="post">
        <div class="input-group mb-3">
          <input type="password" name="newpass" class="form-control" placeholder="Password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control" name="cpass" placeholder="Confirm Password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12">
            <button type="submit" name="update" class="btn btn-primary btn-block">Change password</button>
          </div>
          <!-- /.col -->
        </div>
      </form>

      <p class="mt-3 mb-1">
        <a href="index.php">Login</a>
      </p>
    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>
