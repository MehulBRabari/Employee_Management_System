<?php require_once('config/connection.php'); ?>

<?php

if ($_SESSION['admin_id'] == '')
{
	header('location:index.php');
}


$get_id = $_GET['edit_data'];

$select_query = "SELECT * FROM employee_timeline WHERE id = '$get_id'";

$run_select_query = mysqli_query($conn, $select_query);

$fetch_data = mysqli_fetch_array($run_select_query);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $join_date = $_POST['join_date'];
    $designation = $_POST['designation'];
    $work_description = $_POST['work_description'];
    $first_pro_date = $_POST['first_pro_date'];
    $first_pro_review = $_POST['first_pro_review'];
    $lead_new_pro = $_POST['lead_new_pro'];
    $perform_review = $_POST['perform_review'];
    $promotion_date = $_POST['promotion_date'];
    $promotion_dep = $_POST['promotion_dep'];



    // $insert_timeline_query = "INSERT INTO employee_timeline(employee_id, join_date, designation, work_description, first_pro_date,first_pro_review,lead_new_pro,perform_review,promotion_date,promotion_dep) VALUES('$get_id', '$join_date', '$designation', '$work_description','$first_pro_date','$first_pro_review','$lead_new_pro','$perform_review','$promotion_date','$promotion_dep')";    
    
    $update_timeline_query = "UPDATE employee_timeline SET join_date = '$join_date', designation= '$designation', work_description = '$work_description', first_pro_date = '$first_pro_date', first_pro_review = '$first_pro_review', lead_new_pro = '$lead_new_pro', perform_review = '$perform_review', promotion_date = '$promotion_date',promotion_dep = '$promotion_dep'  WHERE id = '$get_id'";   

   $run_update_query = mysqli_query($conn, $update_timeline_query);

   if($run_update_query)
   {
    
    $success = "success";
    header('refresh:2;URL=#timeline');
   }
  else 
   {
    $fail = 'fail';
   }



}
// } elseif (isset($_POST['delete_event'])) {
//   $event_id = $_POST['event_id'];

//   $delete_timeline_query = "DELETE FROM employee_timeline WHERE id = '$event_id'";
//   mysqli_query($conn, $delete_timeline_query);
// }



?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Timeline Update | codeinweb Technologies</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link rel="stylesheet" type="text/css" href="dist/css/all.min.css">


<!-- Favicon icon -->
<link rel="icon" type="image/x-icon" href="dist/img/codeinweblogo.png" />

</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
 <?php require_once('includes/topnavbar.php'); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
 <?php require_once('includes/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Update Timeline</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <!-- <li class="breadcrumb-item"><a href="#">Home</a></li> -->
              <li class="breadcrumb-item active">Edit Timeline</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    <!-- </section> -->
           <?php if (isset($success)) { ?>
             <div class="alert alert-success alert-dismissible" style="font-size:20px">
                <i class="fa fa-spinner fa-spin" ></i> Update Employee Timeline !!!
              </div>
              <?php } ?>

<!-- /.Fail Alert Box -->
            <?php if (isset($fail)) { ?>
            <div class="alert alert-danger alert-dismissible" style="font-size: 17px">
               <i class="icon fas fa-ban"></i> Timeline Not Update !!!
              </div>
             <?php } ?>
    <!-- Main content -->
    <!-- <section class="content"> -->
      <!-- <div class="container-fluid"> -->
        <div class="row">
          <div class="col-8">
            <!-- /.card -->
            <div class="card-body">
                <div class="card card-primary card-outline">
                  <div class="card-header">
                        <h3 class="card-title">Update Timeline Event</h3>
            <a class="btn btn-secondary float-right" onclick="window.history.go(-1); return false;"><i class="fa fa-backward"></i> Go Back</a>

                  </div>
                    <div class="card-body">
                        <form method="post" action="">
                          <div class="form-group">
                            <label for="join_date">Joining Date</label>
                            <input type="date" class="form-control" value="<?php echo $fetch_data['join_date']; ?>" id="join_date" name="join_date" required>
                          </div>
                          <div class="form-group">
                            <label for="designation">Designation</label>
                            <input type="text" class="form-control" value="<?php echo $fetch_data['designation']; ?>" id="designation" name="designation" required>
                          </div>
                          <div class="form-group">
                            <label for="work_description">Work Description</label>
                            <input type="text" class="form-control" id="work_description" value="<?php echo $fetch_data['work_description']; ?>" name="work_description" required>
                          </div>
                          <div class="form-group">
                            <label for="first_pro_date">First Project Assign Date</label>
                            <input type="date" class="form-control" id="first_pro_date" value="<?php echo $fetch_data['first_pro_date'] ?>" name="first_pro_date" required>
                          </div>

                          <div class="form-group">
                            <label for="first_pro_review">First Project Assign Review</label>
                            <input type="text" class="form-control" id="first_pro_review" value="<?php echo $fetch_data['first_pro_review']; ?>" name="first_pro_review" required></textarea>
                          </div>

                          <div class="form-group">
                            <label for="lead_new_pro">Lead New Project Review</label>
                            <input type="text" class="form-control" id="lead_new_pro" value="<?php echo $fetch_data['lead_new_pro']; ?>" name="lead_new_pro" required>
                          </div>

                          <div class="form-group">
                            <label for="perform_review">Performance Review</label>
                            <input type="text" class="form-control" id="perform_review" value="<?php echo $fetch_data['perform_review']; ?>" name="perform_review" required>
                          </div>
                          
                          <div class="form-group">
                            <label for="promotion_date">Promotion Date</label>
                            <input type="date" class="form-control" id="promotion_date" value="<?php echo $fetch_data['promotion_date']; ?>" name="promotion_date" required>
                          </div>

                          <div class="form-group">
                            <label for="promotion_dep">Promotion Department</label>
                            <input type="text" class="form-control" id="promotion_dep" value="<?php echo $fetch_data['promotion_dep']; ?>" name="promotion_dep" required>
                          </div>
                         
                          <button type="submit" class="btn btn-primary">Update Timeline</button>

                        </form>
                 </div>
             </div>

           </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      <!-- </div> -->
      <!-- /.container-fluid -->
    <!-- </section> -->
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 
<?php require_once('includes/footer.php'); ?>
  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<?php require_once('includes/javascript.php'); ?>

</body>
</html>
