<?php
require "config/connection.php";

if ($_SESSION['admin_id'] == '')
{
	header('location:index.php');
}


$get_id = $_GET['edit_data'];

$select_query = "SELECT * FROM add_employee WHERE id = '$get_id'";

$run_query = mysqli_query($conn,$select_query);

$fetch_data = mysqli_fetch_array($run_query);


if(isset($_POST['update']))
{
  $First_Name = $_POST['first_name'];
  $last_name = $_POST['last_name'];
  $gender = $_POST['gender'];
  $dob = $_POST['dob'];
  $mobile = $_POST['mobile'];
  $emobile = $_POST['emobile'];
  $email = $_POST['email'];
  $designation = $_POST['designation'];
  $position = $_POST['position'];
  $experience = $_POST['experience'];
  $address = $_POST['address'];
  $joining_date = $_POST['joining_date'];
  $employee_proof_id = $_POST['employee_proof_id'];

  //Proof Id Uploaded Updated

  $image = $_FILES['image'];
  
  $file_name = $_FILES['image']['name'];
  $file_size = $_FILES['image']['size'];
  $file_tmp = $_FILES['image']['tmp_name'];
  $file_type = $_FILES['image']['type'];

   $countfiles = count($_FILES['image']['name']);
   for ($i=0; $i < $countfiles ; $i++) { 
   $file_name = $_FILES['image']['name'][$i];

   move_uploaded_file($_FILES['image']['tmp_name'][$i], 'uploaded_images/' . $file_name);
  
   // Reporting Person 
   
  $reporting_person = $_POST['reporting_person'];

  //Employee Uploaded Image Update
  
  $emp_image = $_FILES['emp_image'];

  $file_name = $_FILES['emp_image']['name'];
  $file_size = $_FILES['emp_image']['size'];
  $file_tmp = $_FILES['emp_image']['tmp_name'];
  $file_type = $_FILES['emp_image']['type'];

   $countfiles = count($_FILES['emp_image']['name']);
   for ($i=0; $i < $countfiles ; $i++) { 
   $file_name = $_FILES['emp_image']['name'][$i];

   move_uploaded_file($_FILES['emp_image']['tmp_name'][$i], 'uploaded_images/' . $file_name);

  $update_query = "UPDATE add_employee SET first_name='$First_Name',last_name='$last_name', gender='$gender', dob='$dob', 
  mobile='$mobile',emobile='$emobile',email='$email',designation='$designation',position='$position',
  experience='$experience',address='$address',joining_date='$joining_date',employee_proof_id='$employee_proof_id',image='$file_name',
  reporting_person='$reporting_person', emp_image='$file_name' WHERE id='$get_id'";
  
 $run_update_query = mysqli_query($conn,$update_query);

   }

}

if($run_update_query)
 {
    $success = "success";
    header('refresh:2;URL=manage_all_emp.php');
}
else
{
  $fail = "fail";
}

}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Edit Employee Data | codeinweb Technology</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href="plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Bootstrap4 Duallistbox -->
  <link rel="stylesheet" href="plugins/bootstrap4-duallistbox/bootstrap-duallistbox.min.css">
  <!-- BS Stepper -->
  <link rel="stylesheet" href="plugins/bs-stepper/css/bs-stepper.min.css">
  <!-- dropzonejs -->
  <link rel="stylesheet" href="plugins/dropzone/min/dropzone.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
   
  <link rel="icon" type="image/x-icon" href="dist/img/codeinweblogo.png">


</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
 <?php require_once('includes/topnavbar.php'); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
 <?php require_once('includes/sidebar.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Employee Update Data Form</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <!-- <li class="breadcrumb-item"><a href="#">Home</a></li> -->
              <!-- <li class="breadcrumb-item active">Edit Employee Form</li> -->
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
       
        <!-- /.card -->
<?php if(isset($success))
{ ?>
<div class = "alert alert-success alert-dismissible" style="font-size:20px" >
<i class = "fa fa-spinner fa-spin"></i>DATA UPDATED SUCCESSFUL !! 
</div>
<?php } ?>

<?php if(isset($fail))  
{ ?>
<div class = "alert alert-danger alert-dismissible" style="font-size:20px" >
<i class = "icon fa fas-ban"></i> DATA NOT UPDATED</div>
  <?php } ?>
  
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title">Update Employee Data</h3>
            

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                <i class="fas fa-minus"></i>
              </button>

              <button type="button" class="btn btn-tool" data-card-widget="remove">
                <i class="fas fa-times"></i>
              </button>
            <a class="btn btn-secondary float-right" onclick="window.history.go(-1); return false;"><i class="fa fa-backward"></i> Go Back</a>

            </div>
          </div>

         
          <!-- /.card-header -->
          <form action="" method="post" enctype="multipart/form-data"> 
          <div class="card-body">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label>First Name:</label>
                 <input type="text" name="first_name" value="<?php echo $fetch_data['first_name']; ?>" class="form-control"  required>
                </div>
               </div>
                <!-- /.form-group -->
                <div class="col-md-4">
                <div class="form-group">
                  <label>Last Name:</label>
                  <input type="text" name="last_name"  value="<?php echo $fetch_data['last_name']; ?>" class="form-control" placeholder="Last name" required>
                </div>
                </div>


                <div class="col-md-4">
                <div class="form-group">
                  <label>Gender:</label><br>
                 <input type="radio" name="gender" value="male" <?php if($fetch_data['gender'] == 'male') { echo "checked"; } ?>  required>
                 <label>Male:</label>
                 <input type="radio" name="gender" value="female" <?php if($fetch_data['gender'] == 'female') { echo "checked"; } ?> required>
                 <label>female:</label>
                </div>
               </div>

                <div class="col-md-4">
                <div class="form-group">
                  <label>Date Of Birth:</label>
                  <input type="date" name="dob"  value="<?php echo $fetch_data['dob']; ?>" class="form-control" required>
                </div>
                </div>

                <!-- /.form-group -->
                <div class="col-md-4">
                <div class="form-group">
                  <label>Mobile Number:</label>
                 <input type="tel" name="mobile" value="<?php echo $fetch_data['mobile']; ?>" class="form-control"  required>
                </div>
               </div>

               <div class="col-md-4">
                 <div class="form-group">
                  <label>Emergency Mobile Number:</label>
                  <input type="tel" name="emobile"  value="<?php echo $fetch_data['emobile']; ?>" class="form-control"  required>
                </div>
                </div>

              <!-- /.col -->
              <div class="col-md-4">
              <div class="form-group">
                  <label>Email:</label>
                  <input type="email" name="email" value="<?php echo $fetch_data['email']; ?>" class="form-control" placeholder="Email" required>
                </div>
                </div>

                <!-- /.form-group -->
                <div class="col-md-4">
                <div class="form-group">
                  <label>Designation:</label>
                  <input type="text" name="designation" value="<?php echo $fetch_data['designation']; ?>" class="form-control" placeholder="Designation" required>
                </div>
                </div>

                <div class="col-md-4">
                <div class="form-group">
                  <label>Position:</label>
                  <select class="form-control"  name="position"  required>
                    <option value="Senior" value="Senior" <?php if($fetch_data['position'] == 'Senior') { echo "selected"; } ?>>Senior</option>
                    <option value="Junior"<?php if($fetch_data['position'] == 'Junior') { echo "selected"; } ?>>Junior</option>
                    <option value="Team Leader" <?php if($fetch_data['position'] == 'Team Leader') { echo "selected"; } ?>>Team Leader</option>
                    <option value="Project Manager" <?php if($fetch_data['position'] == 'Project Manager') { echo "selected"; } ?>>Project Manager</option>
                  </select>
               </div>
               </div>


               <div class="col-md-4">
                <div class="form-group">
                  <label>Experience:</label>
                  <select class="form-control" name="experience" required >
                    <!-- <option>Select Your Experience</option> -->
                    <option value="Trained"  <?php if($fetch_data['experience'] == 'Trained') { echo "selected"; } ?> >Trained</option>
                    <option value="Fresher" <?php if($fetch_data['experience'] == 'Fresher') { echo "selected"; }?> >Fresher</option>
                    <option value="1 Year Experience" <?php if($fetch_data['experience'] == '1 Year Experience') { echo "selected"; } ?>>1 Year Experience</option>
                    <option value="2 Year Experience" <?php if($fetch_data['experience'] == '2 Year Experience') { echo "selected"; } ?>>2 Year Experience</option>
                    <option value="3 Year Experience" <?php if($fetch_data['experience'] == '3 Year Experience') { echo "selected"; } ?>>3 Year Experience</option>
                    <option value="4 Year Experience" <?php if($fetch_data['experience'] == '4 Year Experience') { echo "selected"; } ?>>4 Year Experience</option>
                    <option value="5 Year Experience" <?php if($fetch_data['experience'] == '5 Year Experience') { echo "selected"; } ?>>5 Year Experience</option>
                    <option value="6 Year Experience" <?php if($fetch_data['experience'] == '6 Year Experience') { echo "selected"; } ?>>6 Year Experience</option>
                    <option value="7 Year Experience" <?php if($fetch_data['experience'] == '7 Year Experience') { echo "selected"; } ?>>7 Year Experience</option>
                    <option value="8 Year Experience" <?php if($fetch_data['experience'] == '8 Year Experience') { echo "selected"; } ?>>8 Year Experience</option>
                    <option value="9 Year Experience" <?php if($fetch_data['experience'] == '9 Year Experience') { echo "selected"; } ?>>9 Year Experience</option>
                    <option value="110 Year Experience" <?php if($fetch_data['experience'] == '10 Year Experience') { echo "selected"; } ?>>10 Year Experience</option>
                  </select>
               </div>
               </div>
                <!-- /.form-group -->
           
                <div class="col-md-4">
                <div class="form-group">
                  <label>Address:</label>
                  <input type="text" value="<?php echo $fetch_data['address']; ?>" name="address" class="form-control" placeholder="Address" required>
                </div>
                </div>

                <div class="col-md-4">
                <div class="form-group">
                  <label>Joining Date:</label>
                  <input type="date" name="joining_date"  value="<?php echo $fetch_data['joining_date']; ?>" class="form-control" required>
                </div>
                </div>
                
                <div class="col-md-4">
                <div class="form-group">
                  <label>Choose Your Id:</label>
                  <select class="form-control" name="employee_proof_id" required>
                    <option value="PAN Card" <?php if($fetch_data['employee_proof_id'] == 'Pan Card') { echo "selected"; } ?> >PAN Card</option>
                    <option value="Aadhar card" <?php if($fetch_data['employee_proof_id'] == 'Aadhar card') { echo "selected"; } ?> >Aadhar card</option>
                    <option value="Voter ID Card" <?php if($fetch_data['employee_proof_id'] == 'Voter Id card') { echo "selected"; } ?> >Voter ID Card</option>
                  </select>
               </div>
               </div>


              <div class="col-md-4">
                <div class="form-group">
                  <label>Upload ID</label>
                  <input type="file" name="image[]" class="form-control">
                  <?php echo $fetch_data['image']; ?>
                </div>
                </div>
                 
                <div class="col-md-4">
                <div class="form-group">
                  <label>Reporting Person:</label>
                  <select class="form-control" name="reporting_person" >
                    <option value="Manager" <?php if($fetch_data['reporting_person'] == 'Manager') { echo "selected"; } ?> >Manager</option>
                    <option value="HR" <?php if($fetch_data['reporting_person'] == 'HR') { echo "selected"; } ?>>HR</option>
                  </select>
               </div>
               </div>

               <div class="col-md-4">
                <div class="form-group">
                  <label>Employee Image</label>
                  <input type="file" name="emp_image[]" class="form-control">
                  <?php echo $fetch_data['emp_image']; ?>
                </div>
                </div>


              <div class="col-md-12">
                <div class="form-group">
                  <button type="submit" value="update" name="update" class="btn btn-primary">Update</buttton>
                </div>
                </div>
              <!-- /.col -->
    
          </div>
            <!-- /.row -->
          </div>
          <!-- /.card-body -->
          <div class="card-footer">
           
          </div>
        </div>
</form>
    

<div class="row">
</div>
  
<div class="row">
</div>
      
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php require_once("includes/footer.php"); ?>

 
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<?php require_once("includes/javascript.php"); ?>


</body>
</html>
