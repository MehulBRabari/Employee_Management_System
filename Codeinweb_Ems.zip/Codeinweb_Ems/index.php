<?php

require_once('config/connection.php'); 

if (isset($_SESSION['admin_id']) != '') {
  
  header("location:admin_dashboard.php");

}


// if (!isset($_SESSION['admin_id']) || $_SESSION['admin_id'] == '') {
//   header('location:admin_dashboard.php');
//   exit();
// }

if (isset($_POST['submit'])) {
  // Checking Login Credentials //
  $admin_sql = "select * from admin_login where email='". mysqli_real_escape_string($conn, $_POST['email']) . "'AND BINARY password='" . mysqli_real_escape_string($conn, md5($_POST['password'])) . "'";
  $admin_query = mysqli_query($conn, $admin_sql);
  $admin_fetch = mysqli_fetch_array($admin_query);
  $admin_rows = mysqli_num_rows($admin_query);
  if ($admin_rows > 0) {
  
    $_SESSION['admin_id'] = $admin_fetch['admin_id'];
    
    $success = "success";
    header('refresh:2;URL=admin_dashboard.php');
}
  else {
    
    $fail = "fail";
  }
         
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Login | Codeinweb Technologies</title>
  
  <style>
    body {
    
      background-image:url('dist/img/background.jpg');
      background-repeat: no-repeat;
      background-size: cover;
      background-position: center center;
    
  }
    </style>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">

  <link rel="icon" type="image/x-icon" href="dist/img/codeinweblogo.png">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">


<!---Javascript ---->
<script>
function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>

</head>
<body class="hold-transition login-page">

<!-- <div class="col-4">
          <a href="user/user_login.php" type="submit" name="submit" class="btn btn-primary btn-block"></a>
</div> -->

<div class="login-box">
  <div class="login-logo">
    <img src="dist/img/codeinweb.png" height="70" width="230">
   </div>
    <!-- <a href=""><b>Admin</b>Login</a> -->
  <?php if (isset($success)) { ?>
  <div class="alert alert-success alert-dismissible" style="font-size:20px">
    <i class="fa fa-spinner fa-spin" ></i> Good to see you again !!!
  </div>
<?php } ?>

<!-- /.Fail Alert Box -->
<?php if (isset($fail)) { ?>
  <div class="alert alert-danger alert-dismissible" style="font-size: 17px">
    <i class="icon fas fa-ban"></i> Invalid email or password !!!
  </div>
<?php } ?>
  <!-- /.login-logo -->
  <div class="card card-primary card-outline">
  <!-- <div class="card-header text-center">
          <h2><b>Codeinweb Technologies</b></h2>
        </div> -->
    <div class="card-body login-card-body">
      <p class="login-box-msg">Sign in to start your session</p>

      <form action="" method="post">
        <div class="input-group mb-3">
          <input type="email" name="email" class="form-control" placeholder="Email" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password"  name="password"   id="myInput" class="form-control" placeholder="Password" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <!-- <span class="fas fa-lock"></span> -->
              <span onclick="myFunction()" class="fa fa-fw fa-eye field-icon toggle-password"></span>
            
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
          <div class="icheck-primary">
            <p class="mb-1">
                <a href="admin_forgot_password.php">I forgot my password</a>
            </p>
          </div>
          </div>
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" name="submit" class="btn btn-primary btn-block">Sign In</button>
            
            <a href="user/" class="btn btn-secondary btn-block">User Side</a>
          </div>
          <!-- /.col -->
         
        </div>
      
      </form>
      <!-- /.social-auth-links -->

    </div>
    <!-- /.login-card-body -->
  </div>
</div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>
