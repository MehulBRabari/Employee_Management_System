<?php 
include 'config/connection.php';

$user_id = $_GET['Employee_id'];
$status = $_GET['status'];
$updatequery = "UPDATE add_employee SET status=$status WHERE id=$user_id";
mysqli_query($conn,$updatequery);
header('location:manage_all_emp.php');
?>