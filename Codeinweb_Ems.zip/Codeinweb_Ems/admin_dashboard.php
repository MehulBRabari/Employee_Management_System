<?php
require_once('config/connection.php');

if ($_SESSION['admin_id'] == '') {
    header('location:index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Dashboard | Codeinweb Technologies</title>
  <style>
    .list-group-item {
        font-size: 1.2rem;
    }
    .upcoming-birthday {
        background-color: #f9f9f9;
        border-left: 5px solid #ffc107;
        border-right: 5px solid #ffc107;
        padding: 15px;
        margin-bottom: 10px;
        border-radius: 5px;
        position: relative;
    }
    .upcoming-event {
        background-color: #e9f7ef;
        border-left: 5px solid #28a745;
        border-right: 5px solid #28a745;
        padding: 15px;
        margin-bottom: 10px;
        border-radius: 5px;
        position: relative;
    }
    .card-title i {
        margin-left: 10px;
    }
  </style>
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">   
  <link rel="icon" type="image/x-icon" href="dist/img/codeinweblogo.png">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="dist/img/codeinweb.png" alt="AdminLTELogo" height="80" width="190">
  </div>

  <?php require('includes/topnavbar.php'); ?>
  <?php require('includes/sidebar.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item active">Admin Dashboard</li>
            </ol>
          </div>
        </div>
      </div>
    </div>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <!-- Total Employees -->
          <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
              <div class="inner">
                <?php
                $dash_catagory_query = "SELECT * FROM add_employee";
                $dash_category_query_run = mysqli_query($conn, $dash_catagory_query);
                $category_total = mysqli_num_rows($dash_category_query_run);
                if ($category_total) {
                    echo '<h3 style="font-size: 45px" class="mb-0">' . $category_total . '</h3>';
                } else {
                    echo '<h3 style="font-size: 45px" class="mb-0">No Data</h3>';
                }
                ?>
                <p>Total Employees</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="manage_all_emp.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>

          <!-- Salary Data -->
          <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
              <div class="inner">
                <?php
                $dash_catagory_query = "SELECT * FROM employee_salary";
                $dash_category_query_run = mysqli_query($conn, $dash_catagory_query);
                $category_total = mysqli_num_rows($dash_category_query_run);
                if ($category_total) {
                    echo '<h3 style="font-size: 45px" class="mb-0">' . $category_total . '</h3>';
                } else {
                    echo '<h3 style="font-size: 45px" class="mb-0">No Data</h3>';
                }
                ?>
                <p>Salary Data</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="manage_all_emp_salary.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>

          <!-- Employees Leave Data -->
          <div class="col-lg-3 col-6">
            <div class="small-box bg-warning">
              <div class="inner">
                <?php
                $dash_catagory_query = "SELECT * FROM emp_leave";
                $dash_category_query_run = mysqli_query($conn, $dash_catagory_query);
                $category_total = mysqli_num_rows($dash_category_query_run);
                if ($category_total) {
                    echo '<h3 style="font-size: 45px" class="mb-0">' . $category_total . '</h3>';
                } else {
                    echo '<h3 style="font-size: 45px" class="mb-0">No Data</h3>';
                }
                ?>
                <p>Employees Leave Data</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="manage_emp_leave.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>

          <!-- Holiday and Event Schedule -->
          <div class="col-lg-3 col-6">
            <div class="small-box bg-danger">
              <div class="inner">
                <?php
                $dash_catagory_query = "SELECT * FROM schedule_list";
                $dash_category_query_run = mysqli_query($conn, $dash_catagory_query);
                $category_total = mysqli_num_rows($dash_category_query_run);
                if ($category_total) {
                    echo '<h3 style="font-size: 45px" class="mb-0">' . $category_total . '</h3>';
                } else {
                    echo '<h3 style="font-size: 45px" class="mb-0">No Data</h3>';
                }
                ?>
                <p>Holiday And Event Schedule</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="admin_holiday_schedule.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
        </div>

        <!-- Main row for Upcoming Events and Birthdays -->
        <div class="row">
          <!-- Upcoming Events -->
          <div class="col-lg-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Upcoming Events and Holidays <i style="color:green; font-size:25px;" class="fas fa-calendar-alt"></i></h3>
              </div>
              <div class="card-body">
                <div class="upcoming-event">
                <ul class="list-group list-group-flush">
                  
                  <?php             
                  $upcoming_events_query = "SELECT * FROM schedule_list WHERE start_datetime >= NOW() ORDER BY start_datetime ASC";
                  $upcoming_events_result = mysqli_query($conn, $upcoming_events_query);
                  if (!$upcoming_events_result) {
                      die("Query failed: " . mysqli_error($conn));
                  }
                  if (mysqli_num_rows($upcoming_events_result) > 0) {
                      while ($event = mysqli_fetch_assoc($upcoming_events_result)) {
                          echo '<li class="list-group-item">' . htmlspecialchars($event['title']) . ' - ' . date('d M Y', strtotime($event['start_datetime'])) . '</li>';
                      }
                  } else {
                      echo '<li class="list-group-item">No upcoming events</li>';
                  }
                  ?>
            
                </ul>
              </div>
                <button id="togglePastEvents" class="btn btn-primary mt-3">Show Past Events</button>
                <div id="pastEvents" style="display: none;">
                  <div class="upcoming-event">
                  <ul class="list-group list-group-flush mt-3">
                    <?php
                    $past_events_query = "SELECT * FROM schedule_list WHERE start_datetime < NOW() ORDER BY start_datetime DESC";
                    $past_events_result = mysqli_query($conn, $past_events_query);
                    if (!$past_events_result) {
                        die("Query failed: " . mysqli_error($conn));
                    }
                    if (mysqli_num_rows($past_events_result) > 0) {
                        while ($event = mysqli_fetch_assoc($past_events_result)) {
                            echo '<li class="list-group-item">' . htmlspecialchars($event['title']) . ' - ' . date('d M Y', strtotime($event['start_datetime'])) . '</li>';
                        }
                    } else {
                        echo '<li class="list-group-item">No past events</li>';
                    }
                    ?>

                  </ul>
                </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Upcoming Birthdays -->
          <div class="col-lg-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Upcoming Birthdays <i style="color:red;  font-size:25px;" class="fas fa-birthday-cake"></i></h3>
              </div>
              <div class="card-body">
                <div class="upcoming-birthday">
                <ul class="list-group list-group-flush">
                  <?php
                  $upcoming_birthdays_query = "
                      SELECT *, DATE_FORMAT(dob, '%Y') + INTERVAL (YEAR(CURDATE()) - YEAR(dob)) + IF(DATE_FORMAT(dob, '%m-%d') < DATE_FORMAT(NOW(), '%m-%d'), 1, 0) YEAR AS next_birthday
                      FROM add_employee
                      WHERE DATE_FORMAT(dob, '%m-%d') >= DATE_FORMAT(NOW(), '%m-%d')
                      ORDER BY DATE_FORMAT(dob, '%m-%d') ASC
                  ";
                  $upcoming_birthdays_result = mysqli_query($conn, $upcoming_birthdays_query);
                  if (!$upcoming_birthdays_result) {
                      die("Query failed: " . mysqli_error($conn));
                  }
                  if (mysqli_num_rows($upcoming_birthdays_result) > 0) {
                      while ($employee = mysqli_fetch_assoc($upcoming_birthdays_result)) {
                          echo '<li class="list-group-item">' . htmlspecialchars($employee['first_name']) . ' - ' . date('d M', strtotime($employee['dob'])) . '</li>';
                      }
                  } else {
                      echo '<li class="list-group-item">No upcoming birthdays</li>';
                  }
                  ?>
                </ul>
              </div>
                <button id="togglePastBirthdays" class="btn btn-primary mt-3">Show Past Birthdays</button>
                <div id="pastBirthdays" style="display: none;">
                <div class="upcoming-birthday">
                  <ul class="list-group list-group-flush mt-3">
                    <?php
                    $past_birthdays_query = "
                        SELECT *, DATE_FORMAT(dob, '%Y') + INTERVAL (YEAR(CURDATE()) - YEAR(dob)) YEAR AS next_birthday
                        FROM add_employee
                        WHERE DATE_FORMAT(dob, '%m-%d') < DATE_FORMAT(NOW(), '%m-%d')
                        ORDER BY DATE_FORMAT(dob, '%m-%d') DESC
                    ";
                    $past_birthdays_result = mysqli_query($conn, $past_birthdays_query);
                    if (!$past_birthdays_result) {
                        die("Query failed: " . mysqli_error($conn));
                    }
                    if (mysqli_num_rows($past_birthdays_result) > 0) {
                        while ($employee = mysqli_fetch_assoc($past_birthdays_result)) {
                            echo '<li class="list-group-item">' . htmlspecialchars($employee['first_name']) . ' - ' . date('d M', strtotime($employee['dob'])) . '</li>';
                        }
                    } else {
                        echo '<li class="list-group-item">No past birthdays</li>';
                    }
                    $conn->close();
                    ?>
                  </ul>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <?php require('includes/footer.php'); ?>
  <aside class="control-sidebar control-sidebar-dark"></aside>
</div>

<script>
  document.getElementById('togglePastEvents').addEventListener('click', function() {
    var pastEventsDiv = document.getElementById('pastEvents');
    if (pastEventsDiv.style.display === 'none') {
        pastEventsDiv.style.display = 'block';
        this.textContent = 'Hide Past Events';
    } else {
        pastEventsDiv.style.display = 'none';
        this.textContent = 'Show Past Events';
    }
  });

  document.getElementById('togglePastBirthdays').addEventListener('click', function() {
    var pastBirthdays = document.getElementById('pastBirthdays');
    if (pastBirthdays.style.display === 'none') {
        pastBirthdays.style.display = 'block';
        this.textContent = 'Hide Past Birthdays';
    } else {
        pastBirthdays.style.display = 'none';
        this.textContent = 'Show Past Birthdays';
    }
  });
</script>
<?php require('includes/javascript.php'); ?>
</body>
</html>
